# Внешний контекст в рексисе: разложение и retrieval переходов

Код к отчёту «Внешний контекст в рексисе: разложение и retrieval переходов». Всё считается на CPU,
нужны только numpy, scipy и pandas.

## Что внутри

| Папка | Что |
| --- | --- |
| `code/` | конвейер на numpy: данные, энкодер MS-EMA, причинный контекст, все агрегации, разложение, retrieval, статистика |
| `torch_patch/` | восстановленный `recsys/src/data` для репозитория авторов и выгрузка состояний их SASRec |
| `results/` | json и логи всех прогонов, на которых построен отчёт |

Главные файлы в `code/`:

* `data.py` ML-1M по протоколу статьи (rating > 3.5, 5-core, сплит по пользователям 70/10/20)
* `encoder.py` MS-EMA с ручными градиентами, `test_grads.py` сверяет их с конечными разностями
* `context.py` один причинный проход по времени: для каждого запроса соседи, случайные, далёкие, пул авторов, среднее по всем, развёртка по температуре
* `agg_eval.py` агрегаторы статьи, Learnable attention, шлюз local/global, метрики, парный бутстрэп, Шепли
* `retrieval.py` память переходов и все её варианты для разложения (причинная, с будущим, окна по времени, случайная, «только похожие клиенты»)
* `run_diagnostics.py` производная CE по доле контекста: проверка «поможет ли контекст» до обучения

## Запуск на ML-1M (как в отчёте)

```bash
pip install numpy scipy pandas
# ratings.dat из https://grouplens.org/datasets/movielens/1m/
set EXT_ML1M_DAT=C:\data\ml-1m\ratings.dat        # Linux/macOS: export EXT_ML1M_DAT=...
set EXT_WORK=C:\work\ext                           # куда писать кеш и результаты
cd code
python test_grads.py           # проверка градиентов, секунды
python run_encoder2.py         # энкодер, ~4 мин (или скопируйте results/encoder_msema.npz в EXT_WORK и пропустите)
python run_context.py          # причинный контекст, ~1.5 мин
python run_experiments.py      # воспроизведение, разложение, шлюз, ~2 мин
python run_retrieval.py        # разложение через память переходов и адаптивная lambda, ~10 мин
python run_diagnostics.py      # производные CE по доле контекста
python run_selection_bias.py   # контроль «лишние эпохи + максимум по тесту»
python run_adaptive2.py        # адаптивная lambda со сдвигом по NDCG на val
```

Проверка устойчивости на другом энкодере: обучите его в отдельную папку (`EXT_WORK=... EXT_EPOCHS=25 EXT_PATIENCE=100 EXT_KEEP_LAST=1 python run_encoder2.py`), затем `run_context.py` и `run_robust.py` с тем же `EXT_WORK`.
`test_precomputed_route.py` выгружает MS-EMA в формате выгрузки SASRec, чтобы проверить путь через `EXT_STATES`.

В отчёте данные взяты из копии ML-1M в репозитории NCF (тот же файл, другая нумерация фильмов).
С оригинальным `ratings.dat` числа совпадут с точностью до порядка оценок, поставленных в одну секунду.

## Что добавлено после ДЗ3

| Скрипт | Что делает |
| --- | --- |
| `read_rda.py` | читает `.rda` из R без R и pyreadr (нужен для Online Retail II из пакета allanvc/onlineretail2) |
| `run_kriging.py` | кригинг остатков модели по соседям против softmax-смеси (идея KernelRidge из ДЗ3 и GP-теории статьи) |
| `run_eb_lambda.py` | доля соседей lambda = m/(c + m) как в эмпирическом Байесе BG/NBD |
| `run_retail_retrieval.py` | ритейл: память граничных переходов, разложение Шепли G против L, срез по сезону |
| `run_shrink_control.py` | обязательный контроль g = 0: сколько даёт чистое сжатие вектора пользователя без контекста |
| `run_splits.sh` | ML-1M ещё на двух сплитах пользователей (`EXT_SPLIT_SEED`) |

Ритейл (Online Retail II):

```bash
git clone --depth 1 https://github.com/allanvc/onlineretail2
python read_rda.py onlineretail2/data/onlineretail2.rda onlineretail2.pkl
set EXT_RETAIL_PKL=...\onlineretail2.pkl
set EXT_DATASET=retail
set EXT_WORK=C:\work\retail
python run_encoder2.py
set EXT_QUERY_MODE=baskets
python run_context.py
python run_experiments.py
python run_retail_retrieval.py
python run_shrink_control.py
```

Датасет ДЗ3 это анонимизированный Online Retail II. Для статьи публичная версия законна, для посылок ДЗ3 её использовать нельзя по правилам курса.

## Запуск на SASRec авторов (Colab)

Открой `colab/sasrec_external_context.ipynb` в Google Colab, включи T4 GPU и выполни ячейки по порядку. Ноутбук сам:
скачает репозиторий авторов и ML-1M, восстановит `recsys/src/data`, обучит SASRec с выбором эпохи по val,
посчитает контроль лишних эпох, выгрузит состояния и прогонит на них весь numpy-конвейер, включая контроль g = 0.
`torch_patch/sasrec_pipeline.py` можно запускать и без ноутбука, из папки `recsys/` репозитория авторов.

Torch-код писался без torch под рукой. Его логика (окна выгрузки, сплит, датасеты) проверена на заглушке torch,
а numpy-часть, которая читает выгрузку, проверена на выгрузке того же формата из MS-EMA.

Важно для честного сравнения на SASRec: выбирать эпоху по валидационным пользователям, а не по тестовым,
и сравнивать модель с контекстом с базой, дообученной столько же эпох без контекста.
