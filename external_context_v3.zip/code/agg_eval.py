"""Агрегаторы внешнего контекста, их обучение (numpy, ручные градиенты) и оценка.

Скоринг как у SASRec с final='items', head_method='adding' в коде авторов:
    scores = E u + b,   u = (1 - alpha) h + alpha g.
Для итоговых метрик: NDCG@10 и HR@10 по всему каталогу без маскирования
просмотренного (как sklearn.ndcg_score у авторов).
"""
import numpy as np
from encoder import ranks_of, ndcg_hr

ALPHAS = (0.0, 0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8)


def softmax(z, axis=-1):
    """Устойчивый softmax; строка из одних -inf (нет ни одного соседа) даёт нули, а не NaN."""
    zm = z.max(axis, keepdims=True)
    zm = np.where(np.isfinite(zm), zm, 0.0)
    e = np.exp(z - zm)
    s = e.sum(axis, keepdims=True)
    return e / np.where(s > 0, s, 1.0)


class Adam:
    def __init__(self, params, lr=1e-3):
        self.p, self.lr, self.t = params, lr, 0
        self.m = [np.zeros_like(x) for x in params]
        self.v = [np.zeros_like(x) for x in params]

    def step(self, grads):
        self.t += 1
        for i, g in enumerate(grads):
            self.m[i] = 0.9 * self.m[i] + 0.1 * g
            self.v[i] = 0.999 * self.v[i] + 0.001 * g * g
            mh = self.m[i] / (1 - 0.9 ** self.t)
            vh = self.v[i] / (1 - 0.999 ** self.t)
            self.p[i] -= self.lr * mh / (np.sqrt(vh) + 1e-8)


class Lab:
    def __init__(self, model, T, Q, S, n_items, day_cum=None):
        self.E, self.bias = model.E.astype(np.float32), model.b.astype(np.float32)
        self.HT, self.T, self.Q, self.S, self.L = T["H"], T, Q, S, n_items
        g = Q["group"]
        self.idx = dict(train=np.flatnonzero(g == "train"), val=np.flatnonzero(g == "val"),
                        test=np.flatnonzero(g == "test"),
                        test_last=np.flatnonzero((g == "test") & Q["primary"]),
                        val_last=np.flatnonzero((g == "val") & Q["primary"]))
        self.day_cum = day_cum

    # ---------- сбор векторов контекста ----------
    def gather(self, rows):
        m = rows >= 0
        return self.HT[np.where(m, rows, 0)] * m[..., None], m

    def rows_mean(self, key, idx, lo=0, hi=None, zeros_count=False, rows=None, chunk=512):
        out = np.zeros((len(idx), self.HT.shape[1]), np.float32)
        R_all = self.S[key] if rows is None else rows
        for i in range(0, len(idx), chunk):
            R = R_all[idx[i:i + chunk], lo:hi]
            H, m = self.gather(R)
            den = R.shape[1] if zeros_count else np.maximum(1, m.sum(1))
            out[i:i + chunk] = H.sum(1) / np.asarray(den, np.float32).reshape(-1, 1)
        return out

    def topk_softmax(self, idx, k, beta, chunk=512):
        out = np.zeros((len(idx), self.HT.shape[1]), np.float32)
        for i in range(0, len(idx), chunk):
            b = idx[i:i + chunk]
            H, m = self.gather(self.S["top_rows"][b, :k])
            z = np.where(m, beta * self.S["top_sims"][b, :k], -np.inf)
            w = softmax(z, 1)
            out[i:i + chunk] = np.einsum("bn,bnd->bd", w, H)
        return out

    def fixed_attention(self, idx, A=None, chunk=512):
        """Attention авторов по фиксированному пулу (нули неактивных входят в softmax)."""
        out = np.zeros((len(idx), self.HT.shape[1]), np.float32)
        for i in range(0, len(idx), chunk):
            b = idx[i:i + chunk]
            H, m = self.gather(self.S["fixed_rows"][b])
            h = self.Q["h"][b]
            q = h if A is None else h @ A.T
            w = softmax(np.einsum("bnd,bd->bn", H, q), 1)
            out[i:i + chunk] = np.einsum("bn,bnd->bd", w, H)
        return out

    # ---------- оценка ----------
    def eval(self, idx, U=None, aux=None, lam=0.0, chunk=1024):
        """Ранги таргетов. U: векторы пользователя; aux: функция (b)->разреженное p_aux; lam: вес смеси вероятностей."""
        nd = np.zeros(len(idx)); hr = np.zeros(len(idx))
        for i in range(0, len(idx), chunk):
            b = idx[i:i + chunk]
            u = self.Q["h"][b] if U is None else U[i:i + chunk]
            sc = u @ self.E.T + self.bias
            if aux is not None and lam > 0:
                p = softmax(sc, 1) * (1 - lam) + lam * aux(b)
                sc = np.log(p + 1e-30)
            r = ranks_of(sc, self.Q["y"][b])
            n_, h_ = ndcg_hr(r)
            nd[i:i + chunk], hr[i:i + chunk] = n_, h_
        return nd, hr

    def per_user(self, idx, vals):
        users = self.Q["user"][idx]
        uu, inv = np.unique(users, return_inverse=True)
        s = np.bincount(inv, weights=vals); c = np.bincount(inv)
        return uu, s / c

    def mix(self, idx, G, a):
        return (1 - a) * self.Q["h"][idx] + a * G

    def tune_alpha(self, Gval, alphas=ALPHAS):
        """alpha по NDCG@10 на всех val-запросах."""
        best = (-1, 0.0)
        curve = []
        for a in alphas:
            v = self.eval(self.idx["val"], self.mix(self.idx["val"], Gval, a))[0].mean()
            curve.append((a, v))
            if v > best[0] + 1e-12:
                best = (v, a)
        return best[1], curve

    def report(self, name, G_fn=None, alpha=None, U_fn=None, aux=None, lam=None, base=None, extra=None):
        """Считает метрики на test_last и test (5 позиций на пользователя, усреднение по пользователю)."""
        res = dict(name=name)
        if G_fn is not None:
            Gv = G_fn(self.idx["val"])
            if alpha is None:
                alpha, curve = self.tune_alpha(Gv)
                res["alpha_curve"] = curve
            res["alpha"] = alpha
            Ut = self.mix(self.idx["test"], G_fn(self.idx["test"]), alpha)
        elif U_fn is not None:
            Ut = U_fn(self.idx["test"])
        else:
            Ut = None
        nd, hr = self.eval(self.idx["test"], Ut, aux=aux, lam=lam or 0.0)
        prim = self.Q["primary"][self.idx["test"]]
        _, ndu = self.per_user(self.idx["test"], nd)
        _, hru = self.per_user(self.idx["test"], hr)
        res.update(ndcg_last=nd[prim].mean(), hr_last=hr[prim].mean(), ndcg_all=ndu.mean(), hr_all=hru.mean())
        res["_nd_last"], res["_nd_user"] = nd[prim], ndu
        if lam is not None:
            res["lam"] = lam
        if extra:
            res.update(extra)
        if base is not None:
            for key in ("last", "user"):
                d = res[f"_nd_{key}"] - base[f"_nd_{key}"]
                lo, hi, p = paired_bootstrap(d)
                res[f"d_{key}"], res[f"ci_{key}"], res[f"p_{key}"] = d.mean(), (lo, hi), p
        return res


def paired_bootstrap(d, B=4000, seed=0):
    rng = np.random.default_rng(seed)
    n = len(d)
    bs = d[rng.integers(0, n, (B, n))].mean(1)
    lo, hi = np.quantile(bs, [0.025, 0.975])
    p = 2 * min((bs <= 0).mean(), (bs >= 0).mean())
    return lo, hi, min(1.0, max(p, 1.0 / B))


# ---------- Learnable attention (Matrix attention из статьи) ----------
def train_learnable_attention(lab, alpha, epochs=15, lr=1e-3, batch=256, seed=0, log=print):
    rng = np.random.default_rng(seed)
    D = lab.HT.shape[1]
    A = rng.uniform(-1 / np.sqrt(D), 1 / np.sqrt(D), (D, D)).astype(np.float32)
    opt = Adam([A], lr)
    tr = lab.idx["train"]
    curve = []
    best = (-1, None, -1)
    for ep in range(epochs):
        perm = rng.permutation(tr)
        tot = 0
        for i in range(0, len(perm), batch):
            b = perm[i:i + batch]
            H, m = lab.gather(lab.S["fixed_rows"][b])
            h = lab.Q["h"][b]
            Ah = h @ A.T
            w = softmax(np.einsum("bnd,bd->bn", H, Ah), 1)
            g = np.einsum("bn,bnd->bd", w, H)
            u = (1 - alpha) * h + alpha * g
            p = softmax(u @ lab.E.T + lab.bias, 1)
            y = lab.Q["y"][b]
            tot += -np.log(p[np.arange(len(b)), y] + 1e-12).sum()
            p[np.arange(len(b)), y] -= 1
            p /= len(b)
            dg = alpha * (p @ lab.E)
            dw = np.einsum("bnd,bd->bn", H, dg)
            ds = w * (dw - (w * dw).sum(1, keepdims=True))
            dAh = np.einsum("bn,bnd->bd", ds, H)
            opt.step([(dAh.T @ h).astype(np.float32)])
        v = lab.eval(lab.idx["val"], lab.mix(lab.idx["val"], lab.fixed_attention(lab.idx["val"], A), alpha))[0].mean()
        t_nd = lab.eval(lab.idx["test"], lab.mix(lab.idx["test"], lab.fixed_attention(lab.idx["test"], A), alpha))[0]
        tu = lab.per_user(lab.idx["test"], t_nd)[1].mean()
        curve.append((ep, tot / len(tr), v, tu))
        log(f"  LA a={alpha} ep {ep} CE {tot / len(tr):.4f} val {v:.4f} test {tu:.4f}")
        if v > best[0]:
            best = (v, A.copy(), ep)
    return best[1], curve, best[2]


# ---------- Новый метод 1: обучаемый шлюз local/global ----------
class GateLG:
    """u = (1-a) h + a (l g_L + (1-l) g_G), a = sigmoid(w_a f + b_a), l = sigmoid(w_l f + b_l),
    g_L = softmax(beta * cos) по top-K соседям, beta = exp(theta) обучается.
    a и l свои для каждого запроса: это эмпирический Байес с данными-зависимым сжатием."""

    def __init__(self, lab, K=50, a0=0.2, l0=0.5, beta0=20.0, feats=None):
        self.lab, self.K = lab, K
        self.F = self.features(lab.idx["train"])
        self.mu, self.sd = self.F.mean(0), self.F.std(0) + 1e-6
        nf = self.F.shape[1]
        self.wa = np.zeros(nf, np.float32); self.ba = np.array([np.log(a0 / (1 - a0))], np.float32)
        self.wl = np.zeros(nf, np.float32); self.bl = np.array([np.log(l0 / (1 - l0))], np.float32)
        self.th = np.array([np.log(beta0)], np.float32)

    def features(self, idx):
        Q, S = self.lab.Q, self.lab.S
        f = np.stack([np.log(Q["seqlen"][idx]), np.log1p(np.maximum(Q["gap"][idx], 0) / 3600.0),
                      S["top_sims"][idx, 0], S["top_sims"][idx, :10].mean(1),
                      np.log1p(S["n_active"][idx]), S["ent_beta"][idx, 4]], 1)
        return f.astype(np.float32)

    def parts(self, idx):
        f = (self.features(idx) - self.mu) / self.sd
        H, m = self.lab.gather(self.lab.S["top_rows"][idx, :self.K])
        sims = self.lab.S["top_sims"][idx, :self.K]
        beta = float(np.exp(self.th[0]))
        w = softmax(np.where(m, beta * sims, -np.inf), 1)
        gL = np.einsum("bn,bnd->bd", w, H)
        gG = self.lab.S["g_all"][idx]
        a = 1 / (1 + np.exp(-(f @ self.wa + self.ba[0])))
        l = 1 / (1 + np.exp(-(f @ self.wl + self.bl[0])))
        return f, H, m, sims, beta, w, gL, gG, a, l

    def U(self, idx, chunk=512):
        out = np.zeros((len(idx), self.lab.HT.shape[1]), np.float32)
        for i in range(0, len(idx), chunk):
            b = idx[i:i + chunk]
            _, _, _, _, _, _, gL, gG, a, l = self.parts(b)
            h = self.lab.Q["h"][b]
            out[i:i + chunk] = (1 - a)[:, None] * h + a[:, None] * (l[:, None] * gL + (1 - l)[:, None] * gG)
        return out

    def gates(self, idx):
        _, _, _, _, beta, _, _, _, a, l = self.parts(idx)
        return a, l, beta

    def fit(self, epochs=12, lr=3e-3, batch=256, seed=0, log=print):
        lab = self.lab
        rng = np.random.default_rng(seed)
        opt = Adam([self.wa, self.ba, self.wl, self.bl, self.th], lr)
        best = (-1, None)
        curve = []
        for ep in range(epochs):
            perm = rng.permutation(lab.idx["train"])
            tot = 0
            for i in range(0, len(perm), batch):
                b = perm[i:i + batch]
                f, H, m, sims, beta, w, gL, gG, a, l = self.parts(b)
                h = lab.Q["h"][b]
                gm = l[:, None] * gL + (1 - l)[:, None] * gG
                u = (1 - a)[:, None] * h + a[:, None] * gm
                p = softmax(u @ lab.E.T + lab.bias, 1)
                y = lab.Q["y"][b]
                tot += -np.log(p[np.arange(len(b)), y] + 1e-12).sum()
                p[np.arange(len(b)), y] -= 1
                p /= len(b)
                du = p @ lab.E
                da = (du * (gm - h)).sum(1)
                dl = a * (du * (gL - gG)).sum(1)
                dgL = (a * l)[:, None] * du
                dw = np.einsum("bnd,bd->bn", H, dgL)
                dz = w * (dw - (w * dw).sum(1, keepdims=True))
                dbeta = (dz * np.where(m, sims, 0)).sum()
                dza = da * a * (1 - a); dzl = dl * l * (1 - l)
                opt.step([(f.T @ dza).astype(np.float32), np.array([dza.sum()], np.float32),
                          (f.T @ dzl).astype(np.float32), np.array([dzl.sum()], np.float32),
                          np.array([dbeta * beta], np.float32)])
            v = lab.eval(lab.idx["val"], self.U(lab.idx["val"]))[0].mean()
            curve.append((ep, tot / len(perm), v))
            log(f"  Gate ep {ep} CE {tot / len(perm):.4f} val {v:.4f} beta {np.exp(self.th[0]):.1f}")
            if v > best[0]:
                best = (v, [x.copy() for x in (self.wa, self.ba, self.wl, self.bl, self.th)])
        self.wa, self.ba, self.wl, self.bl, self.th = best[1]
        return curve


# ---------- Новый метод 2: причинный retrieval «что сосед сделал дальше» ----------
def knn_dense(items, sims, b, K, tau, L):
    """Плотная p_knn для запросов b: bincount вместо np.add.at (в десятки раз быстрее)."""
    it = items[b, :K]; sm = sims[b, :K]
    ok = it >= 0
    w = softmax(np.where(ok, tau * sm, -np.inf), 1)
    w = np.where(ok, w, 0.0)
    flat = (np.arange(len(b))[:, None] * L + np.maximum(it, 0)).reshape(-1)
    P = np.bincount(flat, weights=w.reshape(-1), minlength=len(b) * L).reshape(len(b), L)
    s = P.sum(1, keepdims=True)
    return np.where(s > 0, P / np.maximum(s, 1e-12), 1.0 / L)


def knn_aux(lab, items, sims, K, tau):
    """p_knn(v) = sum_i softmax(tau * sim_i) [v_i = v] по K ближайшим переходам."""
    return lambda b: knn_dense(items, sims, b, K, tau, lab.L)


# ---------- Новый метод 3: явный «контекст в целом» как популярность за окно ----------
def pop_aux(lab, delta_days, smooth=1.0):
    cum, days = lab.day_cum
    def f(b):
        d = lab.Q["t"][b] // 86400 - 1               # только полностью завершённые дни: причинно
        hi = np.searchsorted(days, d, side="right") - 1
        if delta_days is None:
            lo = np.full_like(hi, -1)
        else:
            lo = np.searchsorted(days, d - delta_days, side="right") - 1
        top = np.where(hi[:, None] >= 0, cum[np.maximum(hi, 0)], 0)
        bot = np.where(lo[:, None] >= 0, cum[np.maximum(lo, 0)], 0)
        c = (top - bot).astype(np.float64) + smooth
        return c / c.sum(1, keepdims=True)
    return f


def shapley2(v0, vG, vL, vGL):
    return dict(phi_G=0.5 * ((vG - v0) + (vGL - vL)), phi_L=0.5 * ((vL - v0) + (vGL - vG)),
                interaction=vGL - vG - vL + v0, total=vGL - v0)
