"""Единая точка выбора энкодера и рабочей папки.

По умолчанию: MS-EMA (numpy) на ML-1M из этой песочницы.
EXT_STATES=путь.npz  -> состояния, выгруженные из SASRec авторов (torch_patch/export_sasrec_states.py)
EXT_WORK=папка       -> куда писать кеши и результаты
EXT_ML1M_DAT=путь    -> оригинальный ratings.dat MovieLens-1M вместо копии из репозитория NCF
"""
import os
import numpy as np

WORK = os.environ.get("EXT_WORK", "/home/claude/ext")
STATES = os.environ.get("EXT_STATES")


class PrecomputedEncoder:
    def __init__(self, path):
        z = np.load(path)
        self.E, self.b = z["E"].astype(np.float32), z["b"].astype(np.float32)
        offs, users = z["offsets"], z["users"]
        S, I, T, sp = z["states"], z["items"], z["ts"], z["split"]
        names = {0: "train", 1: "val", 2: "test"}
        self._st, self.seqs, self.split = {}, {}, {}
        for k, u in enumerate(users):
            a, b = offs[k], offs[k + 1]
            self._st[u] = S[a:b]
            self.seqs[u] = (I[a:b], T[a:b])
            self.split[u] = names[int(sp[k])]
        self.L = self.E.shape[0]

    def user_states(self, u):
        return self._st[u]


def load_encoder_and_data():
    if STATES:
        enc = PrecomputedEncoder(STATES)
        info = dict(source=STATES, n_users=len(enc.seqs), n_items=enc.L)
        return enc, enc.seqs, enc.split, enc.L, info
    from data import prepare
    from encoder import MSEMA
    seqs, split, L, info = prepare()
    return MSEMA.load(f"{WORK}/encoder_msema.npz"), seqs, split, L, info


def load_encoder():
    if STATES:
        return PrecomputedEncoder(STATES)
    from encoder import MSEMA
    return MSEMA.load(f"{WORK}/encoder_msema.npz")
