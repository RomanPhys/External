"""Причинная сборка внешнего контекста одним проходом по времени.

Пул: только train-пользователи (как у авторов). Для запроса с моментом t каждый
пользователь пула представлен последним состоянием h_i(s), s <= t (как в agg.py авторов).
Сам пользователь запроса из пула исключён везде, кроме воспроизведения пула авторов
(фиксированные 100 случайных train-пользователей с нулями для неактивных).

Для каждого запроса сохраняем всё, из чего потом собираются условия разложения:
  top-1000 соседей по косинусу (строки таблицы состояний и сходства), 50 самых далёких,
  100 случайных активных, среднее по всем активным, взвешенные средние softmax(beta*cos)
  по всему пулу, строки пула авторов, соседей по ключу «состояние до последнего события»
  вместе с этим последним айтемом (для причинного retrieval «что сосед сделал дальше»).
"""
import os
import numpy as np

BETAS = (0.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0)
DAY = 86400


def _states(model, u, items):
    """Энкодер-агностично: выгрузка SASRec даёт user_states(u), MS-EMA считает сам."""
    if hasattr(model, "user_states"):
        return model.user_states(u)
    return model.seq_states(items)


def build_state_table(model, seqs, split):
    """Состояния train-пользователей после каждого их события."""
    rows_user, rows_t, rows_item, rows_prev, H_all = [], [], [], [], []
    user_rows = {}
    r0 = 0
    for u in sorted(seqs):
        if split[u] != "train":
            continue
        items, ts = seqs[u]
        H = _states(model, u, items)
        n = len(items)
        H_all.append(H)
        rows_user.append(np.full(n, u))
        rows_t.append(ts)
        rows_item.append(items)
        prev = np.arange(r0 - 1, r0 + n - 1)
        prev[0] = -1
        rows_prev.append(prev)
        user_rows[u] = np.arange(r0, r0 + n)
        r0 += n
    T = dict(H=np.concatenate(H_all).astype(np.float32), user=np.concatenate(rows_user),
             t=np.concatenate(rows_t), item=np.concatenate(rows_item), prev=np.concatenate(rows_prev))
    T["Hn"] = T["H"] / (np.linalg.norm(T["H"], axis=1, keepdims=True) + 1e-9)
    T["user_rows"] = user_rows
    return T


def build_queries(model, seqs, split, n_train_pos=6, n_multi=5, seed=0):
    """Запросы: (группа, пользователь, t, h, таргет, primary)."""
    rng = np.random.default_rng(seed)
    Q = dict(group=[], user=[], t=[], h=[], y=[], primary=[], seqlen=[], gap=[])
    for u in sorted(seqs):
        items, ts = seqs[u]
        n = len(items)
        g = split[u]
        H = _states(model, u, items)
        if g == "train":
            cand = np.arange(1, n - 1)
            pos = rng.choice(cand, size=min(n_train_pos, len(cand)), replace=False)
            prim = np.zeros(len(pos), bool)
        elif os.environ.get("EXT_QUERY_MODE") == "baskets":
            # граница чека: вход до последнего товара чека j, таргет первый товар следующего чека
            bnd = np.flatnonzero(np.diff(ts) > 0)
            if len(bnd) == 0:
                continue
            pos = bnd[-n_multi:]
            prim = pos == bnd[-1]
        else:
            pos = np.arange(max(0, n - 1 - n_multi), n - 1)
            prim = pos == n - 2
        for j, p in zip(pos, prim):
            Q["group"].append(g); Q["user"].append(u); Q["t"].append(ts[j]); Q["h"].append(H[j])
            Q["y"].append(items[j + 1] - 1); Q["primary"].append(p); Q["seqlen"].append(j + 1)
            Q["gap"].append(ts[j] - ts[j - 1] if j > 0 else 0)
    for k in Q:
        Q[k] = np.array(Q[k])
    Q["h"] = Q["h"].astype(np.float32)
    return Q


def sweep(T, Q, train_users, K_top=1000, K_far=50, K_rand=100, K_ret=200, n_fixed=100,
          betas=BETAS, seed=0):
    rng = np.random.default_rng(seed)
    users = np.array(sorted(train_users))
    uidx = {u: i for i, u in enumerate(users)}
    Np, D = len(users), T["H"].shape[1]
    fixed = rng.choice(Np, n_fixed, replace=False)          # пул авторов: один на всё время
    ev = np.lexsort((np.arange(len(T["t"])), T["t"]))         # события по времени
    qord = np.argsort(Q["t"], kind="stable")
    nq = len(Q["t"])
    out = dict(top_rows=np.full((nq, K_top), -1, np.int32), top_sims=np.zeros((nq, K_top), np.float32),
               far_rows=np.full((nq, K_far), -1, np.int32), rand_rows=np.full((nq, K_rand), -1, np.int32),
               fixed_rows=np.full((nq, n_fixed), -1, np.int32), n_active=np.zeros(nq, np.int32),
               g_all=np.zeros((nq, D), np.float32), g_beta=np.zeros((nq, len(betas), D), np.float32),
               ent_beta=np.zeros((nq, len(betas)), np.float32),
               ret_items=np.full((nq, K_ret), -1, np.int32), ret_sims=np.zeros((nq, K_ret), np.float32))
    C = np.zeros((Np, D), np.float32); Cn = np.zeros_like(C)
    Pn = np.zeros_like(C)
    cur = np.full(Np, -1, np.int64); last_item = np.full(Np, -1, np.int64)
    active = np.zeros(Np, bool); has_prev = np.zeros(Np, bool)
    gsum = np.zeros(D, np.float64)
    day_means, day_ids = [], []
    e = 0
    qself = np.array([uidx.get(u, -1) for u in Q["user"]])
    hn_all = Q["h"] / (np.linalg.norm(Q["h"], axis=1, keepdims=True) + 1e-9)
    cur_day = None
    for qi in qord:
        t = Q["t"][qi]
        while e < len(ev) and T["t"][ev[e]] <= t:
            r = ev[e]
            d = T["t"][r] // DAY
            if cur_day is not None and d != cur_day:
                day_ids.append(cur_day); day_means.append((gsum / max(1, active.sum())).astype(np.float32))
            cur_day = d
            i = uidx[T["user"][r]]
            if active[i]:
                gsum -= C[i]
                Pn[i] = Cn[i]; has_prev[i] = True
            C[i] = T["H"][r]; Cn[i] = T["Hn"][r]; cur[i] = r; last_item[i] = T["item"][r]
            active[i] = True
            gsum += C[i]
            e += 1
        s = qself[qi]
        valid = active.copy()
        if s >= 0:
            valid[s] = False
        nv = int(valid.sum())
        out["n_active"][qi] = nv
        fr = cur[fixed].copy()
        fr[~active[fixed]] = -1
        out["fixed_rows"][qi] = fr
        if nv == 0:
            continue
        hn = hn_all[qi]
        sims = Cn @ hn
        vs = np.flatnonzero(valid)
        sv = sims[vs]
        k = min(K_top, nv)
        top = vs[np.argpartition(-sv, k - 1)[:k]] if k < nv else vs
        top = top[np.argsort(-sims[top])][:K_top]
        out["top_rows"][qi, :len(top)] = cur[top]; out["top_sims"][qi, :len(top)] = sims[top]
        kf = min(K_far, nv)
        far = vs[np.argpartition(sv, kf - 1)[:kf]] if kf < nv else vs
        out["far_rows"][qi, :len(far)] = cur[far]
        kr = min(K_rand, nv)
        out["rand_rows"][qi, :kr] = cur[rng.choice(vs, kr, replace=False)]
        gs = gsum - (C[s] if (s >= 0 and active[s]) else 0)
        out["g_all"][qi] = gs / nv
        Cv = C[vs]
        for bi, b in enumerate(betas):
            z = b * sv
            w = np.exp(z - z.max()); w /= w.sum()
            out["g_beta"][qi, bi] = w @ Cv
            out["ent_beta"][qi, bi] = -(w * np.log(w + 1e-12)).sum()
        pv = np.flatnonzero(valid & has_prev)
        if len(pv):
            ps = Pn[pv] @ hn
            kk = min(K_ret, len(pv))
            sel = np.argpartition(-ps, kk - 1)[:kk] if kk < len(pv) else np.arange(len(pv))
            sel = sel[np.argsort(-ps[sel])]
            out["ret_items"][qi, :kk] = last_item[pv[sel]] - 1
            out["ret_sims"][qi, :kk] = ps[sel]
    out["fixed_users"] = users[fixed]
    out["day_ids"] = np.array(day_ids); out["day_means"] = np.array(day_means)
    return out


def full_transition_retrieval(T, Q, qmask, K=100, chunk=64):
    """Память всех переходов train-пользователей (ключ h_i(s_j), значение x_{j+1}),
    причинная: переход виден запросу, только если x_{j+1} случился не позже t."""
    nxt = np.arange(1, len(T["t"]) + 1)
    ok = nxt < len(T["t"])
    nxt = np.where(ok, nxt, 0)
    same = ok & (T["user"][nxt] == T["user"])
    keys = np.flatnonzero(same)
    Kn = T["Hn"][keys]
    vals = T["item"][keys + 1] - 1
    t_done = T["t"][keys + 1]
    qs = np.flatnonzero(qmask)
    items = np.full((len(Q["t"]), K), -1, np.int32); sims = np.zeros((len(Q["t"]), K), np.float32)
    owner = np.full((len(Q["t"]), K), -1, np.int64)
    hn = Q["h"] / (np.linalg.norm(Q["h"], axis=1, keepdims=True) + 1e-9)
    kuser = T["user"][keys]
    for i in range(0, len(qs), chunk):
        b = qs[i:i + chunk]
        S = hn[b] @ Kn.T
        S[t_done[None, :] > Q["t"][b][:, None]] = -np.inf
        S[kuser[None, :] == Q["user"][b][:, None]] = -np.inf
        top = np.argpartition(-S, K, axis=1)[:, :K]
        ts = np.take_along_axis(S, top, 1)
        o = np.argsort(-ts, 1)
        top = np.take_along_axis(top, o, 1); ts = np.take_along_axis(ts, o, 1)
        iv = vals[top].astype(np.int32)
        iv[~np.isfinite(ts)] = -1
        items[b] = iv; sims[b] = np.where(np.isfinite(ts), ts, 0); owner[b] = kuser[top]
    return items, sims, owner
