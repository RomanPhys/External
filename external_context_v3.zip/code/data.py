"""MovieLens-1M по протоколу RecSys-пайплайна статьи (IEEE Access 2026, раздел IV-D4).

Фильтры как в recsys/config/dataset/movielens_1m.yaml авторов:
  rating > 3.5, 5-core по пользователям и айтемам.
Сплит как на рисунке 8 статьи: user-based (пользователи теста не участвуют
ни в обучении, ни в пуле внешнего контекста) + leave-one-out внутри теста.
Отличие от авторов: отдельная валидационная группа пользователей, чтобы
выбирать эпоху и гиперпараметры не на тесте.
"""
import numpy as np
import pandas as pd

import os
RAW = os.environ.get("EXT_NCF_DIR", "/home/claude/ext/data_src/ncf/Data")  # или задайте EXT_ML1M_DAT


def load_ml1m():
    import os
    cols = ["user", "item", "rating", "ts"]
    dat = os.environ.get("EXT_ML1M_DAT")
    if dat:
        return pd.read_csv(dat, sep="::", engine="python", names=cols)
    a = pd.read_csv(f"{RAW}/ml-1m.train.rating", sep="\t", names=cols)
    b = pd.read_csv(f"{RAW}/ml-1m.test.rating", sep="\t", names=cols)
    return pd.concat([a, b], ignore_index=True)


def k_core(df, k_user=5, k_item=5):
    while True:
        n = len(df)
        ic = df["item"].value_counts()
        df = df[df["item"].isin(ic[ic >= k_item].index)]
        uc = df["user"].value_counts()
        df = df[df["user"].isin(uc[uc >= k_user].index)]
        if len(df) == n:
            return df


def load_retail(max_events=1000):
    """Online Retail II (UCI), публичная копия в R-пакете allanvc/onlineretail2, прочитана read_rda.py.
    Покупка: товарный код из 5 цифр, не отмена, Quantity > 0, Price > 0, есть клиент; точные повторы удалены;
    одна строка на (клиент, чек, товар). У оптовиков оставлены последние max_events событий."""
    import os
    path = os.environ.get("EXT_RETAIL_PKL", "/home/claude/ext/retail/onlineretail2.pkl")
    r = pd.read_pickle(path).drop_duplicates()
    r = r[r["CustomerID"].notna() & ~r["Invoice"].str.startswith("C") & (r["Quantity"] > 0) & (r["Price"] > 0)
          & r["StockCode"].str.match(r"^\d{5}")]
    r = r.reset_index(drop=True).reset_index()
    ev = (r.groupby(["CustomerID", "Invoice", "StockCode"], sort=False)
            .agg(ts=("InvoiceDate", "min"), order=("index", "min")).reset_index())
    ev = ev.sort_values(["CustomerID", "ts", "order"], kind="stable")
    ev = ev.groupby("CustomerID", sort=False).tail(max_events)
    out = pd.DataFrame({"user": ev["CustomerID"].astype(np.int64).to_numpy(),
                        "item": ev["StockCode"].to_numpy(),
                        "rating": 5,
                        "ts": ev["ts"].to_numpy().astype("datetime64[s]").astype(np.int64)})
    return out


def prepare(seed=None, frac=(0.7, 0.1, 0.2), thr=3.5):
    import os
    if seed is None:
        seed = int(os.environ.get("EXT_SPLIT_SEED", 0))
    df = load_retail() if os.environ.get("EXT_DATASET") == "retail" else load_ml1m()
    n_raw = len(df)
    df = df[df["rating"] > thr]
    df = k_core(df)
    # айтемы 1..L, 0 зарезервирован под паддинг
    items = np.sort(df["item"].unique())
    imap = {it: i + 1 for i, it in enumerate(items)}
    df = df.assign(item=df["item"].map(imap))
    # стабильная сортировка внутри пользователя по времени
    df = df.sort_values(["user", "ts"], kind="stable")
    users = np.sort(df["user"].unique())
    rng = np.random.default_rng(seed)
    perm = rng.permutation(users)
    n_tr = int(frac[0] * len(users))
    n_va = int(frac[1] * len(users))
    split = {u: "train" for u in perm[:n_tr]}
    split.update({u: "val" for u in perm[n_tr:n_tr + n_va]})
    split.update({u: "test" for u in perm[n_tr + n_va:]})
    seqs = {}
    for u, g in df.groupby("user", sort=True):
        seqs[u] = (g["item"].to_numpy(np.int64), g["ts"].to_numpy(np.int64))
    info = dict(n_raw=n_raw, n_inter=len(df), n_users=len(users), n_items=len(items),
                n_train=n_tr, n_val=n_va, n_test=len(users) - n_tr - n_va,
                t_min=int(df["ts"].min()), t_max=int(df["ts"].max()))
    return seqs, split, len(items), info


if __name__ == "__main__":
    seqs, split, L, info = prepare()
    print(info)
    lens = np.array([len(s[0]) for s in seqs.values()])
    print("len: mean %.1f median %d max %d" % (lens.mean(), np.median(lens), lens.max()))
    # сколько пар событий у одного пользователя приходится на одну и ту же секунду
    ties = np.mean([np.mean(np.diff(t) == 0) for _, t in seqs.values()])
    print("share of zero time gaps inside users: %.3f" % ties)
