"""Последовательный энкодер MS-EMA, обучаемый полным cross-entropy, на чистом numpy.

Зачем не SASRec: в этой песочнице нет torch и GPU. MS-EMA сохраняет всё, что важно
для изучения внешнего контекста:
  * причинность: h_t зависит только от событий до t включительно;
  * скор линеен по вектору пользователя: r = E h + b, как у SASRec с final='items',
    поэтому смешивание u = (1-a) h + a g работает ровно как в статье;
  * обучение полным CE по всем позициям последовательности, как у авторов.

h_t = [ EMA_{g_1}(Q_1[x]), ..., EMA_{g_K}(Q_K[x]) ],   EMA_g: S_t = g S_{t-1} + Q[x_t],  h = S_t / Z_t
Блок с g=0 это эмбеддинг последнего айтема (марковская часть), g=0.97 это долгий вкус.
"""
import time
import numpy as np
import scipy.sparse as sp

GAMMAS = (0.0, 0.8, 0.97)
DIMS = (16, 24, 24)


class MSEMA:
    def __init__(self, n_items, gammas=GAMMAS, dims=DIMS, seed=0, item_freq=None):
        rng = np.random.default_rng(seed)
        self.L, self.g, self.dims = n_items, gammas, dims
        self.D = int(sum(dims))
        self.dt = np.float32
        self.Q = [(0.1 * rng.standard_normal((n_items + 1, d))).astype(np.float32) for d in dims]
        for q in self.Q:
            q[0] = 0
        self.E = (0.1 * rng.standard_normal((n_items, self.D))).astype(np.float32)
        self.b = np.zeros(n_items, np.float32)
        if item_freq is not None:
            self.b = np.log(item_freq + 1.0).astype(np.float32)
            self.b -= self.b.mean()

    # ---------- прямой проход ----------
    def batch_states(self, X):
        """X: (B,T) айтемы с правым паддингом нулями. Возвращает H (B,T,D), Z список (T,)."""
        B, T = X.shape
        out = np.zeros((B, T, self.D), self.dt)
        Zs = []
        off = 0
        for k, (g, d) in enumerate(zip(self.g, self.dims)):
            Qx = self.Q[k][X]  # (B,T,d)
            S = np.zeros((B, d), self.dt)
            Z = np.zeros(T, self.dt)
            z = 0.0
            for j in range(T):
                S = g * S + Qx[:, j]
                z = g * z + 1.0
                Z[j] = z
                out[:, j, off:off + d] = S / z
            Zs.append(Z)
            off += d
        return out, Zs

    def seq_states(self, items):
        H, _ = self.batch_states(items[None, :])
        return H[0]

    def scores(self, U):
        return U @ self.E.T + self.b

    # ---------- обучение ----------
    def loss_grads(self, seqs, last_k=200):
        T = max(len(s) for s in seqs)
        X = np.zeros((len(seqs), T), np.int64)
        M = np.zeros((len(seqs), T), bool)
        Y = np.zeros((len(seqs), T), np.int64)
        for r, s in enumerate(seqs):
            n = len(s)
            X[r, :n] = s
            Y[r, :n - 1] = s[1:]
            lo = max(0, n - 1 - last_k)
            M[r, lo:n - 1] = True
        H, Zs = self.batch_states(X)
        idx = np.nonzero(M)
        h = H[idx]                       # (N,D)
        y = Y[idx] - 1
        logits = h @ self.E.T + self.b
        logits -= logits.max(1, keepdims=True)
        p = np.exp(logits)
        p /= p.sum(1, keepdims=True)
        N = len(y)
        tot = -np.log(p[np.arange(N), y] + 1e-12).sum()
        cnt = N
        p[np.arange(N), y] -= 1.0
        p /= N
        gE = p.T @ h
        gb = p.sum(0)
        dh = p @ self.E                  # (N,D)
        dH = np.zeros_like(H)
        dH[idx] = dh
        grads = []
        off = 0
        for k, (g, d) in enumerate(zip(self.g, self.dims)):
            dS = dH[:, :, off:off + d] / Zs[k][None, :, None]
            G = np.zeros((X.shape[0], d), self.dt)
            acc = np.zeros_like(dS)
            for j in range(T - 1, -1, -1):
                G = dS[:, j] + g * G
                acc[:, j] = G
            rows = X.reshape(-1)
            oh = sp.csr_matrix((np.ones(len(rows), self.dt), (rows, np.arange(len(rows)))),
                               shape=(self.L + 1, len(rows)))
            gq = np.asarray(oh @ acc.reshape(-1, d), dtype=self.dt)
            gq[0] = 0
            grads.append(gq)
            off += d
        grads += [gE.astype(self.dt), gb.astype(self.dt)]
        return tot, cnt, grads

    def fit(self, train_seqs, val_fn, epochs=30, batch=64, lr=2e-3, wd=0.0, last_k=200,
            patience=4, seed=0, log=print, keep_last=False):
        rng = np.random.default_rng(seed)
        params = self.Q + [self.E, self.b]
        m = [np.zeros_like(p) for p in params]
        v = [np.zeros_like(p) for p in params]
        b1, b2, eps, step = 0.9, 0.999, 1e-8, 0
        order = np.argsort([len(s) for s in train_seqs])
        best, best_state, bad, hist = -1, None, 0, []
        for ep in range(epochs):
            t0 = time.time()
            chunks = [order[i:i + batch] for i in range(0, len(order), batch)]
            rng.shuffle(chunks)
            tot, cnt = 0.0, 0
            for ch in chunks:
                seqs = [train_seqs[i] for i in ch]
                bl, bc, grads = self.loss_grads(seqs, last_k)
                tot += bl
                cnt += bc
                step += 1
                for i, (pp, gg) in enumerate(zip(params, grads)):
                    m[i] = b1 * m[i] + (1 - b1) * gg
                    v[i] = b2 * v[i] + (1 - b2) * gg * gg
                    mh = m[i] / (1 - b1 ** step)
                    vh = v[i] / (1 - b2 ** step)
                    pp -= lr * (mh / (np.sqrt(vh) + eps) + wd * pp)
                for q in self.Q:
                    q[0] = 0
            val = val_fn(self)
            hist.append((ep, tot / cnt, val))
            log(f"epoch {ep:2d} train CE {tot / cnt:.4f} val NDCG@10 {val:.4f} ({time.time() - t0:.0f}s)")
            if val > best:
                best, bad = val, 0
                best_state = [p.copy() for p in params]
            else:
                bad += 1
                if bad >= patience:
                    break
        if not keep_last:
            for p, s in zip(params, best_state):
                p[...] = s
        return hist

    def save(self, path):
        np.savez(path, E=self.E, b=self.b, g=np.array(self.g), dims=np.array(self.dims),
                 **{f"Q{k}": q for k, q in enumerate(self.Q)})

    @staticmethod
    def load(path):
        z = np.load(path)
        dims = tuple(int(x) for x in z["dims"])
        m = MSEMA(z["E"].shape[0], tuple(float(x) for x in z["g"]), dims)
        m.Q = [z[f"Q{k}"] for k in range(len(dims))]
        m.E, m.b = z["E"], z["b"]
        return m


def ranks_of(scores, targets):
    """Ранг таргета (1 = лучший) по полному каталогу, без маскирования просмотренного (как у авторов)."""
    if not np.isfinite(scores).all():
        raise ValueError("non-finite scores: NaN would silently become rank 1")
    t = scores[np.arange(len(targets)), targets]
    return 1 + (scores > t[:, None]).sum(1)


def ndcg_hr(ranks, k=10):
    nd = np.where(ranks <= k, 1.0 / np.log2(ranks + 1), 0.0)
    hr = (ranks <= k).astype(float)
    return nd, hr
