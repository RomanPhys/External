"""Минимальный читатель .rda (сериализация R, формат XDR) без R и pyreadr.

Поддерживает то, из чего состоит data.frame: строковые, целые, вещественные, логические векторы,
списки, пары-списки атрибутов, символы и ссылки на них, ALTREP compact_*seq и wrap_*.
"""
import bz2, gzip, lzma, struct
import numpy as np

NILVALUE, REFSXP, SYMSXP, LISTSXP, CHARSXP, LGLSXP, INTSXP, REALSXP, STRSXP, VECSXP = 254, 255, 1, 2, 9, 10, 13, 14, 16, 19
SPECIAL = {253: "globalenv", 242: "emptyenv", 241: "baseenv", 251: "missing", 247: "basenamespace", 252: "unbound"}
ALTREP = 238
NA_INT = -2147483648


class R:
    def __init__(self, raw):
        self.b, self.p, self.refs = raw, 0, []

    def int(self):
        v = struct.unpack_from(">i", self.b, self.p)[0]; self.p += 4; return v

    def ints(self, n):
        a = np.frombuffer(self.b, dtype=">i4", count=n, offset=self.p).astype(np.int64); self.p += 4 * n; return a

    def reals(self, n):
        a = np.frombuffer(self.b, dtype=">f8", count=n, offset=self.p).astype(np.float64); self.p += 8 * n; return a

    def charsxp_body(self):
        n = self.int()
        if n == -1:
            return None
        s = self.b[self.p:self.p + n].decode("utf-8", "replace"); self.p += n; return s

    def item(self):
        flags = self.int()
        t = flags & 0xFF
        has_attr, has_tag = bool(flags & (1 << 9)), bool(flags & (1 << 10))
        if t == NILVALUE:
            return None
        if t in SPECIAL:
            return SPECIAL[t]
        if t == REFSXP:
            idx = flags >> 8
            if idx == 0:
                idx = self.int()
            return self.refs[idx - 1]
        if t == SYMSXP:
            name = self.item()                    # CHARSXP
            sym = ("sym", name)
            self.refs.append(sym)
            return sym
        if t == LISTSXP:
            attr = self.item() if has_attr else None
            tag = self.item() if has_tag else None
            car = self.item()
            cdr = self.item()
            node = [(tag[1] if isinstance(tag, tuple) else tag, car)]
            if isinstance(cdr, list):
                node += cdr
            return node
        if t == CHARSXP:
            return self.charsxp_body()
        if t == ALTREP:
            info = self.item(); state = self.item(); attr = self.item()
            cls = info[0][1][1] if isinstance(info, list) else None
            if cls in ("compact_intseq", "compact_realseq"):
                n, start, step = state
                return {"data": start + step * np.arange(int(n)), "attr": attr}
            if isinstance(cls, str) and cls.startswith("wrap_"):
                return state[0][1] if isinstance(state, list) else state
            if cls == "deferred_string":
                base = state[0][1] if isinstance(state, list) else state
                return {"data": np.array([str(x) for x in base["data"]], dtype=object), "attr": attr}
            raise ValueError(f"unsupported ALTREP {cls}")
        if t in (LGLSXP, INTSXP):
            n = self.int(); data = self.ints(n)
        elif t == REALSXP:
            n = self.int(); data = self.reals(n)
        elif t == STRSXP:
            n = self.int(); data = np.empty(n, dtype=object)
            for i in range(n):
                f2 = self.int()
                data[i] = self.charsxp_body()
        elif t == VECSXP:
            n = self.int(); data = [self.item() for _ in range(n)]
        else:
            raise ValueError(f"unsupported SEXP type {t} at {self.p}")
        attr = self.item() if has_attr else None
        return {"data": data, "attr": attr}


def read_rda(path):
    raw = open(path, "rb").read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    elif raw[:3] == b"BZh":
        raw = bz2.decompress(raw)
    elif raw[:6] == b"\xfd7zXZ\x00":
        raw = lzma.decompress(raw)
    assert raw[:5] in (b"RDX2\n", b"RDX3\n"), raw[:5]
    r = R(raw)
    r.p = 5
    assert raw[r.p:r.p + 2] == b"X\n"; r.p += 2
    version = r.int(); r.int(); r.int()
    if version == 3:
        n = r.int(); r.p += n
    top = r.item()
    return {name: val for name, val in top}


def to_frame(obj):
    import pandas as pd
    attrs = dict(obj["attr"] or [])
    names = list(attrs["names"]["data"])
    cols = {}
    for name, col in zip(names, obj["data"]):
        d = col["data"]
        a = dict(col["attr"] or [])
        cls = list(a["class"]["data"]) if "class" in a else []
        if "levels" in a:
            lev = np.array(list(a["levels"]["data"]) + [None], dtype=object)
            d = lev[np.where(d == NA_INT, len(lev) - 1, d - 1)]
        elif "POSIXct" in cls:
            d = pd.to_datetime(d, unit="s", utc=True)
            tz = a.get("tzone")
            if tz is not None and tz["data"][0]:
                d = d.tz_convert(tz["data"][0])
            d = d.tz_localize(None)
        cols[name] = d
    return pd.DataFrame(cols)


if __name__ == "__main__":
    import sys, time
    t0 = time.time()
    objs = read_rda(sys.argv[1])
    for k, v in objs.items():
        df = to_frame(v)
        print(k, df.shape, "%.1fs" % (time.time() - t0))
        print(df.head()); print(df.dtypes)
        df.to_parquet(sys.argv[2]) if sys.argv[2].endswith(".parquet") else df.to_pickle(sys.argv[2])
