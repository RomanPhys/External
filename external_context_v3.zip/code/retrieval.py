"""Память переходов пула и её варианты для разложения эффекта.

Переход train-пользователя: ключ = его состояние h после события j (префикс),
значение = следующий айтем x_{j+1}, время завершения = t_{j+1}.

Варианты (все исключают пользователя запроса):
  causal       переходы, завершённые не позже t (честный режим);
  noncausal    вся память, включая будущее относительно t (утечка, только как верхняя граница);
  window=d     только переходы, завершённые в (t - d дней, t]   («что делают сейчас»);
  stale=d      только переходы, завершённые не позже t - d дней («что делали раньше»);
  random       K случайных причинных переходов без учёта сходства (контроль = популярность);
  users=k      только переходы k пользователей, самых похожих по ТЕКУЩЕМУ состоянию
               («совсем похожие клиенты»), против всей памяти («похожие ситуации»).
"""
import numpy as np


class TransitionMemory:
    def __init__(self, T):
        n = len(T["t"])
        nxt = np.arange(1, n + 1)
        ok = nxt < n
        same = np.zeros(n, bool)
        same[ok] = T["user"][nxt[ok]] == T["user"][ok]
        keys = np.flatnonzero(same)
        self.keys = keys
        self.Kn = T["Hn"][keys]
        self.val = (T["item"][keys + 1] - 1).astype(np.int32)
        self.t_done = T["t"][keys + 1]
        self.user = T["user"][keys]
        o = np.argsort(self.t_done, kind="stable")
        self.by_time = o
        self.t_sorted = self.t_done[o]
        self.user_keys = {}
        for u in np.unique(self.user):
            self.user_keys[u] = np.flatnonzero(self.user == u)
        self.T = T

    def query(self, Q, qidx, K=100, mode="causal", days=None, users_k=None, S=None, chunk=64, seed=0,
              return_keys=False):
        rng = np.random.default_rng(seed)
        hn = Q["h"] / (np.linalg.norm(Q["h"], axis=1, keepdims=True) + 1e-9)
        items = np.full((len(Q["t"]), K), -1, np.int32)
        sims = np.zeros((len(Q["t"]), K), np.float32)
        owner = np.full((len(Q["t"]), K), -1, np.int64)
        kidx = np.full((len(Q["t"]), K), -1, np.int64)
        if mode == "random":
            for q in qidx:
                c = np.searchsorted(self.t_sorted, Q["t"][q], side="right")
                if c == 0:
                    continue
                pick = self.by_time[rng.integers(0, c, size=4 * K)]
                pick = pick[self.user[pick] != Q["user"][q]][:K]
                items[q, :len(pick)] = self.val[pick]; sims[q, :len(pick)] = 0.0
                owner[q, :len(pick)] = self.user[pick]
            return items, sims, owner
        if mode == "users":
            for q in qidx:
                rows = S["top_rows"][q, :users_k]
                us = np.unique(self.T["user"][rows[rows >= 0]])
                if len(us) == 0:
                    continue
                ks = np.concatenate([self.user_keys[u] for u in us if u in self.user_keys])
                ks = ks[self.t_done[ks] <= Q["t"][q]]
                if len(ks) == 0:
                    continue
                s = self.Kn[ks] @ hn[q]
                kk = min(K, len(ks))
                sel = np.argpartition(-s, kk - 1)[:kk] if kk < len(ks) else np.arange(len(ks))
                sel = sel[np.argsort(-s[sel])]
                items[q, :kk] = self.val[ks[sel]]; sims[q, :kk] = s[sel]; owner[q, :kk] = self.user[ks[sel]]
            return items, sims, owner
        for i in range(0, len(qidx), chunk):
            b = qidx[i:i + chunk]
            Smat = hn[b] @ self.Kn.T
            tq = Q["t"][b][:, None]
            if mode == "causal":
                bad = self.t_done[None, :] > tq
            elif mode == "noncausal":
                bad = np.zeros_like(Smat, bool)
            elif mode == "window":
                bad = (self.t_done[None, :] > tq) | (self.t_done[None, :] <= tq - days * 86400)
            elif mode == "stale":
                bad = self.t_done[None, :] > tq - days * 86400
            else:
                raise ValueError(mode)
            bad |= self.user[None, :] == Q["user"][b][:, None]
            Smat[bad] = -np.inf
            top = np.argpartition(-Smat, K, axis=1)[:, :K]
            ts = np.take_along_axis(Smat, top, 1)
            o = np.argsort(-ts, 1)
            top = np.take_along_axis(top, o, 1); ts = np.take_along_axis(ts, o, 1)
            fin = np.isfinite(ts)
            iv = self.val[top].astype(np.int32); iv[~fin] = -1
            items[b] = iv; sims[b] = np.where(fin, ts, 0); owner[b] = np.where(fin, self.user[top], -1)
            kidx[b] = np.where(fin, top, -1)
        if return_keys:
            return items, sims, owner, kidx
        return items, sims, owner


def dedupe_owner(items, sims, owner):
    """Оставляет по одному (самому похожему) переходу от каждого пользователя."""
    it2 = np.full_like(items, -1); s2 = np.zeros_like(sims)
    for q in range(len(items)):
        if items[q, 0] < 0:
            continue
        _, first = np.unique(owner[q], return_index=True)
        first = np.sort(first[owner[q][first] >= 0])
        it2[q, :len(first)] = items[q, first]; s2[q, :len(first)] = sims[q, first]
    return it2, s2
