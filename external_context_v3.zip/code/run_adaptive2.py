"""Адаптивная lambda, вторая попытка.

Первая версия учила lambda(x) по NLL и проиграла фиксированной lambda по NDCG:
NLL-оптимальная доля retrieval меньше, чем доля, оптимальная для топ-10.
Здесь форма lambda(x) = sigmoid(w f + b) учится по NLL на train, а общий сдвиг
delta в логите подбирается на val по NDCG@10: lambda = sigmoid(w f + b + delta).
Так адаптивность (кому больше, кому меньше) берётся из правдоподобия, а уровень из ранжирования.
"""
import json, pickle, time
import numpy as np
from config import WORK, load_encoder
from encoder import ranks_of, ndcg_hr
from agg_eval import Lab, softmax, knn_dense, paired_bootstrap, Adam
from retrieval import TransitionMemory

t0 = time.time()
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
Q, S = lab.Q, lab.S
vi, ti, tri = lab.idx["val"], lab.idx["test"], lab.idx["train"]
K, tau, lam_fixed = 100, 5.0, 0.3
mem = TransitionMemory(C["T"])
it_tr, sm_tr, _ = mem.query(Q, tri, K=K, mode="causal")
items = S["fret_items"].copy(); sims = S["fret_sims"].copy()
items[tri], sims[tri] = it_tr[tri], sm_tr[tri]
print("retrieval ready %.0fs" % (time.time() - t0), flush=True)

def feats(idx, chunk=1024):
    pm_y, pk_y, F = [], [], []
    for i in range(0, len(idx), chunk):
        b = idx[i:i + chunk]
        pm = softmax(Q["h"][b] @ lab.E.T + lab.bias, 1)
        pk = knn_dense(items, sims, b, K, tau, lab.L)
        y = Q["y"][b]
        pm_y.append(pm[np.arange(len(b)), y]); pk_y.append(pk[np.arange(len(b)), y])
        sb = sims[b, :K]
        w = softmax(np.where(items[b, :K] >= 0, tau * sb, -np.inf), 1)
        F.append(np.stack([sb[:, 0], sb[:, :10].mean(1), -(w * np.log(w + 1e-12)).sum(1), pk.max(1), pm.max(1),
                           -(pm * np.log(pm + 1e-12)).sum(1), np.log(Q["seqlen"][b]),
                           np.log1p(np.maximum(Q["gap"][b], 0) / 3600)], 1))
    return np.concatenate(pm_y), np.concatenate(pk_y), np.concatenate(F)

pm_tr, pk_tr, F_tr = feats(tri)
mu, sd = F_tr.mean(0), F_tr.std(0) + 1e-6
Fz = (F_tr - mu) / sd
w = np.zeros(Fz.shape[1]); b0 = np.array([np.log(lam_fixed / (1 - lam_fixed))])
opt = Adam([w, b0], lr=0.02)
for _ in range(600):
    lam = 1 / (1 + np.exp(-(Fz @ w + b0[0])))
    p = (1 - lam) * pm_tr + lam * pk_tr
    dz = (-(pk_tr - pm_tr) / (p + 1e-12)) * lam * (1 - lam) / len(lam)
    opt.step([Fz.T @ dz, np.array([dz.sum()])])

def ndcg_with(idx, delta, chunk=1024):
    _, _, F = feats(idx)
    lam_all = 1 / (1 + np.exp(-(((F - mu) / sd) @ w + b0[0] + delta)))
    nd = np.zeros(len(idx))
    for i in range(0, len(idx), chunk):
        bb = idx[i:i + chunk]; lm = lam_all[i:i + chunk]
        p = softmax(Q["h"][bb] @ lab.E.T + lab.bias, 1) * (1 - lm)[:, None] + lm[:, None] * knn_dense(items, sims, bb, K, tau, lab.L)
        nd[i:i + chunk] = ndcg_hr(ranks_of(np.log(p + 1e-30), Q["y"][bb]))[0]
    return nd, lam_all

curve = []
for delta in (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
    v = ndcg_with(vi, delta)[0].mean()
    curve.append((delta, float(v)))
    print("delta", delta, "val", round(v, 4), flush=True)
best_delta = max(curve, key=lambda x: x[1])[0]
fixed_val = lab.eval(vi, aux=lambda b: knn_dense(items, sims, b, K, tau, lab.L), lam=lam_fixed)[0].mean()
nd_t, lam_t = ndcg_with(ti, best_delta)
base = lab.report("base")
_, ndu = lab.per_user(ti, nd_t)
fixed_nd = lab.eval(ti, aux=lambda b: knn_dense(items, sims, b, K, tau, lab.L), lam=lam_fixed)[0]
_, fu = lab.per_user(ti, fixed_nd)
d = ndu - base["_nd_user"]; lo, hi, p = paired_bootstrap(d)
d2 = ndu - fu; lo2, hi2, p2 = paired_bootstrap(d2)
prim = Q["primary"][ti]
out = dict(delta_curve_val=curve, best_delta=best_delta, fixed_val=float(fixed_val),
           ndcg_all=float(ndu.mean()), d_all=float(d.mean()), ci_all=(lo, hi), p_all=p,
           ndcg_last=float(nd_t[prim].mean()), d_last=float((nd_t[prim] - base["_nd_last"]).mean()),
           vs_fixed=float(d2.mean()), vs_fixed_ci=(lo2, hi2), vs_fixed_p=p2,
           lam_mean=float(lam_t.mean()), lam_q10=float(np.quantile(lam_t, 0.1)), lam_q90=float(np.quantile(lam_t, 0.9)),
           weights=w.tolist())
print(json.dumps(out, indent=1, default=float), "%.0fs" % (time.time() - t0))
json.dump(out, open(f"{WORK}/results_adaptive2.json", "w"), indent=1, default=float)
