"""Строит таблицу состояний пула, запросы и весь причинный контекст, кеширует в npz."""
import pickle, time
import numpy as np
from config import WORK, load_encoder_and_data
from context import build_state_table, build_queries, sweep, full_transition_retrieval

t0 = time.time()
model, seqs, split, L, info = load_encoder_and_data()
T = build_state_table(model, seqs, split)
Q = build_queries(model, seqs, split)
print("state rows", len(T["t"]), "queries", {g: int((Q["group"] == g).sum()) for g in ("train", "val", "test")},
      "%.0fs" % (time.time() - t0))
train_users = [u for u in seqs if split[u] == "train"]
S = sweep(T, Q, train_users)
print("sweep done %.0fs" % (time.time() - t0))
qmask = Q["group"] != "train"
ri, rs, ro = full_transition_retrieval(T, Q, qmask)
S["fret_items"], S["fret_sims"], S["fret_owner"] = ri, rs, ro
print("full retrieval done %.0fs" % (time.time() - t0))
# дневные кумулятивные счётчики айтемов среди train-событий (для популярности за окно)
days = T["t"] // 86400
ud = np.unique(days)
cum = np.zeros((len(ud), L), np.int32)
pos = np.searchsorted(ud, days)
cnt = np.zeros((len(ud), L), np.int32)
np.add.at(cnt, (pos, T["item"] - 1), 1)
cum = np.cumsum(cnt, 0).astype(np.int32)
T_small = {k: v for k, v in T.items() if k != "user_rows"}
pickle.dump(dict(T=T_small, Q=Q, S=S, day_cum=(cum, ud), L=L, info=info),
            open(f"{WORK}/cache_context.pkl", "wb"), protocol=4)
print("saved %.0fs" % (time.time() - t0))
na = S["n_active"]
for g in ("val", "test"):
    m = Q["group"] == g
    print(g, "active pool size at query time: median %d, 10%% %d" % (np.median(na[m]), np.quantile(na[m], 0.1)))
fa = (S["fixed_rows"] >= 0).sum(1)
print("authors' fixed pool (100): active median %d, 10%% %d" % (np.median(fa), np.quantile(fa, 0.1)))
