"""Диагностика «поможет ли контекст» до всякого обучения агрегатора.

Векторная форма (статья): L(a) = CE(E((1-a)h + a g) + b, y).
    dL/da |_{a=0} = E[(g - h)^T E^T (p - y)].
У энкодера, сошедшегося по E и b, E[(p - y) h^T] = 0 и E[p - y] = 0 (условия стационарности),
поэтому производная равна E[g^T E^T (p - y)]: это ковариация остатков модели с контекстом.
Отрицательная производная значит, что малая доля контекста снижает CE.

Вероятностная форма (retrieval): L(l) = -log((1-l) p_y + l q_y).
    dL/dl |_{l=0} = 1 - E[q_y / p_y].
Контекст помогает в первом порядке, если в среднем q кладёт на истину больше массы, чем p.
"""
import json, pickle
import numpy as np
from config import WORK, load_encoder
from agg_eval import Lab, softmax, knn_dense
from context import BETAS

C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
Q, S = lab.Q, lab.S
out = {}
for split_name in ("train", "val"):
    idx = lab.idx[split_name]
    if split_name == "train":
        idx = idx[:8000]
    h = Q["h"][idx]
    P = softmax(h @ lab.E.T + lab.bias, 1)
    R = P.copy(); R[np.arange(len(idx)), Q["y"][idx]] -= 1      # p - y
    res = R @ lab.E                                               # E^T (p - y), по запросам
    stat = dict(stationarity_h=float(np.abs((res * h).sum(1).mean())),
                stationarity_bias=float(np.abs(R.mean(0)).sum()))
    conds = {"Mean пул авторов (с нулями)": lab.rows_mean("fixed_rows", idx, zeros_count=True),
             "G: среднее по всем": S["g_all"][idx],
             "L: 10 ближайших": lab.rows_mean("top_rows", idx, 0, 10),
             "L: 1 ближайший": lab.rows_mean("top_rows", idx, 0, 1),
             "beta=50 (3 эфф. соседа)": S["g_beta"][idx, BETAS.index(50.0)]}
    d = {}
    for name, G in conds.items():
        der = ((G - h) * res).sum(1)
        se = der.std() / np.sqrt(len(der))
        d[name] = dict(dCE_dalpha=float(der.mean()), se=float(se))
    if split_name == "val" and "fret_items" in S:
        q = knn_dense(S["fret_items"], S["fret_sims"], idx, 100, 5.0, lab.L)
        ratio = q[np.arange(len(idx)), Q["y"][idx]] / P[np.arange(len(idx)), Q["y"][idx]]
        d["retrieval: все причинные переходы (вероятности)"] = dict(
            dCE_dlambda=float(1 - ratio.mean()), se=float(ratio.std() / np.sqrt(len(ratio))),
            share_q_gt_p=float((ratio > 1).mean()))
    out[split_name] = dict(stationarity=stat, derivatives=d)
    print(split_name, json.dumps(out[split_name], indent=1, ensure_ascii=False))
json.dump(out, open(f"{WORK}/diagnostics.json", "w"), indent=1, ensure_ascii=False)
