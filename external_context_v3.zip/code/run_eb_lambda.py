"""Эмпирико-байесовская доля соседей: lambda(h) = m(h) / (c + m(h)), идея BG/NBD из ДЗ3.

Дирихле-априор с центром в предсказании модели и концентрацией c, соседи дают m(h) псевдонаблюдений:
    p_hat = (c p_model + m q) / (c + m),   m(h) = sum_i exp(tau_m (cos(h, k_i) - 1)) по K причинным переходам.
Близкие и многочисленные соседи дают большое m и большую долю retrieval, далёкие почти нулевую.
Один гиперпараметр c (и ширина tau_m), против фиксированной lambda и выученного шлюза.
"""
import json, pickle
import numpy as np
from config import WORK, load_encoder
from encoder import ranks_of, ndcg_hr
from agg_eval import Lab, softmax, knn_dense, paired_bootstrap

C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
Q, S = lab.Q, lab.S
vi, ti = lab.idx["val"], lab.idx["test"]
K, tau = 100, 5.0
items, sims = S["fret_items"], S["fret_sims"]

def run(idx, mode, a, b=None, chunk=1024):
    nd = np.zeros(len(idx)); lam_out = np.zeros(len(idx))
    for i in range(0, len(idx), chunk):
        bb = idx[i:i + chunk]
        Pm = softmax(Q["h"][bb] @ lab.E.T + lab.bias, 1)
        q = knn_dense(items, sims, bb, K, tau, lab.L)
        ok = items[bb, :K] >= 0
        if mode == "fixed":
            lam = np.full(len(bb), a)
        else:
            m = np.where(ok, np.exp(b * (sims[bb, :K] - 1)), 0).sum(1)
            lam = m / (a + m)
        p = (1 - lam)[:, None] * Pm + lam[:, None] * q
        nd[i:i + chunk] = ndcg_hr(ranks_of(np.log(p + 1e-30), Q["y"][bb]))[0]
        lam_out[i:i + chunk] = lam
    return nd, lam_out

fixed_v = {l: run(vi, "fixed", l)[0].mean() for l in (0.2, 0.3, 0.4)}
best_fixed = max(fixed_v, key=fixed_v.get)
grid = {}
for b in (5.0, 10.0, 20.0, 50.0):
    for c in (1.0, 3.0, 10.0, 30.0, 100.0):
        grid[(b, c)] = run(vi, "eb", c, b)[0].mean()
best = max(grid, key=grid.get)
base = lab.report("base")
nd_f, _ = run(ti, "fixed", best_fixed)
nd_e, lam_e = run(ti, "eb", best[1], best[0])
fu = lab.per_user(ti, nd_f)[1]; eu = lab.per_user(ti, nd_e)[1]
d = eu - base["_nd_user"]; lo, hi, p = paired_bootstrap(d)
d2 = eu - fu; lo2, hi2, p2 = paired_bootstrap(d2)
sl = Q["seqlen"][ti]
out = dict(best_fixed=best_fixed, val_fixed=fixed_v, best_eb=dict(tau_m=best[0], c=best[1]), val_eb=float(grid[best]),
           grid_val={f"tau_m={k[0]},c={k[1]}": float(v) for k, v in grid.items()},
           test_eb=float(eu.mean()), test_fixed=float(fu.mean()), d_vs_base=float(d.mean()), ci_vs_base=(lo, hi),
           d_vs_fixed=float(d2.mean()), ci_vs_fixed=(lo2, hi2), p_vs_fixed=p2,
           lam_mean=float(lam_e.mean()), lam_q10_q90=(float(np.quantile(lam_e, .1)), float(np.quantile(lam_e, .9))),
           corr_lambda_seqlen=float(np.corrcoef(np.log(sl), lam_e)[0, 1]))
print(json.dumps(out, indent=1, default=float))
json.dump(out, open(f"{WORK}/results_eb_lambda.json", "w"), indent=1, default=float)
