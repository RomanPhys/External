"""Обучение энкодера MS-EMA на train-пользователях, выбор эпохи по val-пользователям."""
import json, os, time
from config import WORK
import numpy as np
from data import prepare
from encoder import MSEMA, ranks_of, ndcg_hr

seqs, split, L, info = prepare()
tr = [seqs[u][0] for u in seqs if split[u] == "train"]
va = [seqs[u][0] for u in seqs if split[u] == "val"]
te = [seqs[u][0] for u in seqs if split[u] == "test"]
freq = np.bincount(np.concatenate(tr) - 1, minlength=L).astype(np.float64)

def last_item_eval(m, group):
    H = np.stack([m.seq_states(s[:-1])[-1] for s in group])
    y = np.array([s[-1] - 1 for s in group])
    return ndcg_hr(ranks_of(m.scores(H), y))

m = MSEMA(L, item_freq=freq, seed=0)
t0 = time.time()
hist = m.fit(tr, lambda mm: last_item_eval(mm, va)[0].mean(), epochs=int(os.environ.get("EXT_EPOCHS", 40)), batch=64, lr=2e-3, patience=int(os.environ.get("EXT_PATIENCE", 4)), keep_last=bool(int(os.environ.get("EXT_KEEP_LAST", 0))))
m.save(f"{WORK}/encoder_msema.npz")
pop_scores = np.log(freq + 1)[None, :]
res = {}
for name, g in (("val", va), ("test", te)):
    nd, hr = last_item_eval(m, g)
    y = np.array([s[-1] - 1 for s in g])
    pnd, phr = ndcg_hr(ranks_of(np.repeat(pop_scores, len(g), 0), y))
    res[name] = dict(ndcg10=nd.mean(), hr10=hr.mean(), pop_ndcg10=pnd.mean(), pop_hr10=phr.mean(), n=len(g))
print(json.dumps(res, indent=1), "time %.0fs" % (time.time() - t0))
json.dump(dict(info=info, hist=hist, res=res), open(f"{WORK}/encoder_log.json", "w"), indent=1, default=float)
