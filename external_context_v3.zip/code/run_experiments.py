"""Все эксперименты на ML-1M: воспроизведение, разложение local/global, новые методы."""
import json, pickle, time
import numpy as np
from config import WORK, load_encoder
from agg_eval import (Lab, softmax, train_learnable_attention, GateLG, knn_aux, pop_aux,
                      shapley2, paired_bootstrap)
from context import BETAS

t0 = time.time()
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
model = load_encoder()
lab = Lab(model, C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
R = {}
LOG = open(f"{WORK}/experiments.log", "w")


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True); LOG.write(s + "\n"); LOG.flush()


def keep(r, group):
    R.setdefault(group, []).append(r)
    s = f"[{group}] {r['name']:<38} last {r['ndcg_last']:.4f} all {r['ndcg_all']:.4f}"
    if "d_user" in r:
        s += f"  d_all {r['d_user']:+.4f} CI [{r['ci_user'][0]:+.4f},{r['ci_user'][1]:+.4f}] p={r['p_user']:.3f}"
    if "alpha" in r:
        s += f"  a={r['alpha']}"
    if "lam" in r:
        s += f"  lam={r['lam']}"
    log(s)
    return r


base = keep(lab.report("Without context"), "A_replication")
se_last = base["_nd_last"].std() / np.sqrt(len(base["_nd_last"]))
se_all = base["_nd_user"].std() / np.sqrt(len(base["_nd_user"]))
log(f"SE of NDCG@10: last-item {se_last:.4f} (n={len(base['_nd_last'])}), 5-pos user-avg {se_all:.4f}")

# ====================== A. Воспроизведение протокола авторов ======================
fixed_mean = lambda idx: lab.rows_mean("fixed_rows", idx, zeros_count=True)
def fixed_max(idx):
    H, m = lab.gather(lab.S["fixed_rows"][idx])
    return H.max(1)   # нули неактивных участвуют, как в torch.max у авторов
for a in (0.01, 0.1, None):
    keep(lab.report(f"Mean (пул авторов, a={a or 'tuned'})", fixed_mean, alpha=a, base=base), "A_replication")
keep(lab.report("Max (пул авторов, tuned)", fixed_max, base=base), "A_replication")
keep(lab.report("Attention (пул авторов, tuned)", lambda idx: lab.fixed_attention(idx), base=base), "A_replication")

la_curves = {}
for a in (0.1, 0.01):
    A, curve, ep = train_learnable_attention(lab, a, epochs=15, log=log)
    la_curves[a] = curve
    r = lab.report(f"Learnable attention (a={a})", lambda idx: lab.fixed_attention(idx, A), alpha=a, base=base,
                   extra=dict(best_epoch_by_val=ep))
    keep(r, "A_replication")
    # насколько завышает выбор эпохи по тесту, как в train.py авторов
    test_by_ep = np.array([c[3] for c in curve])
    r["test_if_epoch_chosen_on_test"] = float(test_by_ep.max())
    r["test_at_val_epoch"] = float(test_by_ep[ep])
    log(f"   selection on test: max over epochs {test_by_ep.max():.4f} vs val-chosen {test_by_ep[ep]:.4f}")
R["la_curves"] = {str(k): v for k, v in la_curves.items()}

# доля self в пуле авторов у train-запросов и утечка через одинаковые секунды
Q, S, T = lab.Q, lab.S, lab.T
tr = lab.idx["train"]
fr = S["fixed_rows"][tr]
self_in = (T["user"][np.where(fr >= 0, fr, 0)] == Q["user"][tr][:, None]) & (fr >= 0)
has_self = self_in.any(1)
leak = np.zeros(len(tr), bool)
for qi, (row_list, hs) in enumerate(zip(fr, self_in)):
    if hs.any():
        r_self = row_list[hs][0]
        # строка-состояние self «новее» запроса: значит в пул попал таргет
        leak[qi] = T["t"][r_self] == Q["t"][tr[qi]] and r_self != -1 and \
            np.any(T["item"][r_self] == Q["y"][tr[qi]] + 1)
R["self_in_fixed_pool_train_share"] = float(has_self.mean())
R["self_state_contains_target_share"] = float(leak.mean())
log(f"train queries with self in authors' pool: {has_self.mean():.3%}; of all train queries, self-state already contains target: {leak.mean():.3%}")

# ====================== B. Разложение: похожие против контекста в целом ======================
G_all = lambda idx: lab.S["g_all"][idx]
gb = keep(lab.report("G: среднее по всем активным", G_all, base=base), "B_decomposition")
for k in (10, 100):
    keep(lab.report(f"G: {k} случайных", lambda idx, k=k: lab.rows_mean("rand_rows", idx, 0, k), base=base),
         "B_decomposition")
knn_res = {}
for k in (1, 5, 10, 50, 100):
    knn_res[k] = keep(lab.report(f"L: {k} ближайших (mean)", lambda idx, k=k: lab.rows_mean("top_rows", idx, 0, k),
                                 base=base, extra=dict(k=k)), "B_decomposition")
for k in (10, 50):
    keep(lab.report(f"Анти: {k} самых далёких", lambda idx, k=k: lab.rows_mean("far_rows", idx, 0, k), base=base),
         "B_decomposition")
for lo, hi in ((0, 10), (10, 50), (50, 200), (200, 1000)):
    keep(lab.report(f"Ранги {lo + 1}-{hi}", lambda idx, lo=lo, hi=hi: lab.rows_mean("top_rows", idx, lo, hi),
                    base=base, extra=dict(band=(lo + 1, hi))), "B_decomposition")

# контроль «соседи чужого запроса того же времени»: ломаем связь сосед <-> пользователь, время сохраняем
def shuffled(fn):
    def f(idx):
        G = fn(idx)
        o = np.argsort(Q["t"][idx], kind="stable")
        Gs = np.empty_like(G)
        Gs[o] = G[np.roll(o, 1)]
        same = Q["user"][idx][o] == Q["user"][idx][np.roll(o, 1)]
        if same.any():  # у пользователя 5 запросов подряд: сдвигаем дальше
            Gs[o] = G[np.roll(o, 7)]
        return Gs
    return f
keep(lab.report("Контроль: 10 ближайших чужого запроса", shuffled(lambda idx: lab.rows_mean("top_rows", idx, 0, 10)),
                base=base), "B_decomposition")

# контроль времени для глобального контекста: то же среднее, но d дней назад
day_ids, day_means = S["day_ids"], S["day_means"]
def g_lag(days):
    def f(idx):
        d = Q["t"][idx] // 86400 - days
        j = np.searchsorted(day_ids, d, side="left") - 1      # строго до дня d
        return np.where((j >= 0)[:, None], day_means[np.maximum(j, 0)], 0).astype(np.float32)
    return f
for d in (1, 30, 180, 365):
    keep(lab.report(f"G: среднее по всем {d} дн. назад", g_lag(d), base=base), "B_decomposition")

# температурная развёртка: beta = 0 это Mean, beta -> inf это 1-NN
beta_curve = []
for bi, b in enumerate(BETAS):
    r = lab.report(f"softmax(beta*cos) по всему пулу, beta={b}", lambda idx, bi=bi: lab.S["g_beta"][idx, bi],
                   base=base, extra=dict(beta=b))
    vi = lab.idx["test"]
    r["eff_neighbors"] = float(np.exp(lab.S["ent_beta"][vi, bi]).mean())
    keep(r, "B_temperature")
    beta_curve.append(dict(beta=b, eff=r["eff_neighbors"], ndcg_all=r["ndcg_all"], d=r["d_user"],
                           ci=r["ci_user"], alpha=r["alpha"]))
R["beta_curve"] = beta_curve

# Шепли по двум источникам: G (всё население) и L (лучший kNN на валидации)
best_k = max(knn_res, key=lambda k: lab.eval(lab.idx["val"], lab.mix(lab.idx["val"],
             lab.rows_mean("top_rows", lab.idx["val"], 0, k), knn_res[k]["alpha"]))[0].mean())
L_fn = lambda idx: lab.rows_mean("top_rows", idx, 0, best_k)
vi, ti = lab.idx["val"], lab.idx["test"]
GLv, LLv = G_all(vi), L_fn(vi)
best = (-1, None)
for a in (0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6):
    for l in (0.0, 0.25, 0.5, 0.75, 1.0):
        v = lab.eval(vi, lab.mix(vi, l * LLv + (1 - l) * GLv, a))[0].mean()
        if v > best[0]:
            best = (v, (a, l))
a_, l_ = best[1]
rGL = lab.report(f"G+L: фикс. смесь (a={a_}, l={l_}, k={best_k})",
                 U_fn=lambda idx: lab.mix(idx, l_ * L_fn(idx) + (1 - l_) * G_all(idx), a_), base=base)
keep(rGL, "B_decomposition")
rL = knn_res[best_k]
sh = {}
for key in ("ndcg_last", "ndcg_all"):
    sh[key] = shapley2(base[key], gb[key], rL[key], rGL[key])
R["shapley"] = dict(best_k=best_k, a=a_, l=l_, **sh)
log("Shapley:", json.dumps(sh, indent=1))

# ====================== C. Новые методы ======================
gate = GateLG(lab, K=50, a0=max(0.05, a_), l0=min(max(l_, 0.1), 0.9))
gcurve = gate.fit(epochs=12, log=log)
rg = keep(lab.report("NEW Шлюз local/global (обучаемые a, l, beta)", U_fn=gate.U, base=base), "C_new")
a_t, l_t, beta_t = gate.gates(lab.idx["test"])
Fm = gate.features(lab.idx["test"])
R["gate"] = dict(beta=float(beta_t), a_mean=float(a_t.mean()), l_mean=float(l_t.mean()),
                 corr_seqlen_a=float(np.corrcoef(Fm[:, 0], a_t)[0, 1]), corr_seqlen_l=float(np.corrcoef(Fm[:, 0], l_t)[0, 1]),
                 corr_top10sim_l=float(np.corrcoef(Fm[:, 3], l_t)[0, 1]),
                 w_a=gate.wa.tolist(), w_l=gate.wl.tolist(),
                 features=["log seqlen", "log gap h", "top1 cos", "mean top10 cos", "log n_active", "entropy b=20"])
log("gate stats", R["gate"])

def tune_mix(name, aux_maker, grid, group="C_new"):
    best = (-1, None)
    for params in grid:
        aux, lam = aux_maker(*params[:-1]), params[-1]
        v = lab.eval(vi, aux=aux, lam=lam)[0].mean()
        if v > best[0]:
            best = (v, params)
    p = best[1]
    r = lab.report(f"{name} {p}", aux=aux_maker(*p[:-1]), lam=p[-1], base=base, extra=dict(params=list(map(str, p))))
    return keep(r, group)

lams = (0.05, 0.1, 0.2, 0.3, 0.5)
grid = [(K, tau, lam) for K in (20, 50, 100) for tau in (5.0, 20.0, 50.0) for lam in lams]
r_ret1 = tune_mix("NEW Retrieval: последний переход соседа (K,tau,lam)",
                  lambda K, tau: knn_aux(lab, S["ret_items"], S["ret_sims"], K, tau), grid)
r_ret2 = tune_mix("NEW Retrieval: все причинные переходы (K,tau,lam)",
                  lambda K, tau: knn_aux(lab, S["fret_items"], S["fret_sims"], K, tau), grid)
grid_pop = [(d, lam) for d in (1, 7, 30, None) for lam in (0.02, 0.05, 0.1, 0.2, 0.3)]
r_pop = tune_mix("Популярность за окно (дней, lam)", lambda d: pop_aux(lab, d), grid_pop, group="C_new")

# комбинация: шлюз в пространстве эмбеддингов + retrieval в пространстве вероятностей
p2 = r_ret2["params"]
K2, tau2, lam2 = int(p2[0]), float(p2[1]), float(p2[2])
aux2 = knn_aux(lab, S["fret_items"], S["fret_sims"], K2, tau2)
best = (-1, None)
for lam in lams:
    v = lab.eval(vi, gate.U(vi), aux=aux2, lam=lam)[0].mean()
    if v > best[0]:
        best = (v, lam)
keep(lab.report(f"NEW Шлюз + retrieval (lam={best[1]})", U_fn=gate.U, aux=aux2, lam=best[1], base=base), "C_new")

# где помогает: выигрыш по терцилям длины истории (5 позиций на пользователя)
def by_len(r_nd_fn, name):
    ti = lab.idx["test"]
    sl = Q["seqlen"][ti]
    qs = np.quantile(sl, [1 / 3, 2 / 3])
    nd0 = lab.eval(ti)[0]
    nd1 = r_nd_fn(ti)
    out = []
    for lo, hi, lbl in ((0, qs[0], "короткая"), (qs[0], qs[1], "средняя"), (qs[1], 1e9, "длинная")):
        m = (sl > lo) & (sl <= hi)
        u, d = lab.per_user(ti[m], nd1[m] - nd0[m])
        lo_, hi_, p = paired_bootstrap(d)
        out.append(dict(bin=lbl, n_users=len(u), base=float(nd0[m].mean()), gain=float(d.mean()), ci=(lo_, hi_)))
    R.setdefault("by_len", {})[name] = out
    log("by length", name, out)
by_len(lambda ti: lab.eval(ti, gate.U(ti))[0], "Шлюз local/global")
by_len(lambda ti: lab.eval(ti, aux=aux2, lam=lam2)[0], "Retrieval все переходы")
by_len(lambda ti: lab.eval(ti, lab.mix(ti, G_all(ti), gb["alpha"]))[0], "G среднее по всем")

def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items() if not str(k).startswith("_")}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    return o
R["meta"] = dict(se_last=float(se_last), se_all=float(se_all), n_test_users=int(len(base["_nd_user"])),
                 info=C["info"], runtime_s=time.time() - t0)
json.dump(clean(R), open(f"{WORK}/results.json", "w"), indent=1, ensure_ascii=False)
log("done %.0fs" % (time.time() - t0))
