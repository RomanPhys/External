"""Кригинг-агрегация внешнего контекста (идея из GP-теории статьи и KernelRidge из ДЗ3).

Для каждого айтема v функция f_v(s) = P(next = v | состояние s). Модель даёт среднее m_v(s).
Остаток r_v = f_v - m_v моделируем гауссовским процессом с ядром k(a, b) = exp(tau (cos(a, b) - 1))
и шумом rho. Наблюдения: K ближайших причинных переходов, y_i = onehot(следующий айтем соседа).
Апостериорное среднее в точке запроса h (BLUP, ко-кригинг остатков):
    f(h) = p_model(h) + w^T (Y - P_model(keys)),   w = (K_nn + rho I)^{-1} k(h, keys).
Отличия от softmax-retrieval: (1) веса учитывают, что соседи дублируют друг друга;
(2) коррекция сама затухает, когда соседи далеко (k мал), то есть адаптивная lambda без обучения;
(3) поправка только там, где модель ошиблась на соседях (остаток), а не повтор того, что модель знает.
Варианты для разложения эффекта:
    nw_mix      p = (1-l) p_model + l * sum softmax(tau cos)_i y_i        (как раньше)
    nw_resid    f = p_model + beta * sum softmax(tau cos)_i (y_i - p_model(key_i))   (остаток, веса NW)
    krig_mix    p = (1-l) p_model + l * norm(clip(w^T Y))                  (веса кригинга, без остатка)
    krig_resid  f = p_model + w^T (Y - P_model(keys))                      (полный кригинг)
"""
import json, pickle, time
import numpy as np
from config import WORK, load_encoder
from encoder import ranks_of, ndcg_hr
from agg_eval import Lab, softmax, paired_bootstrap
from retrieval import TransitionMemory

t0 = time.time()
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
Q, T = lab.Q, C["T"]
mem = TransitionMemory(T)
vi, ti = lab.idx["val"], lab.idx["test"]
ev = np.concatenate([vi, ti])
K = 100
items, sims, owner, kidx = mem.query(Q, ev, K=K, mode="causal", return_keys=True)
print("retrieval %.0fs" % (time.time() - t0), flush=True)

TAUS_K, RHOS = (2.0, 5.0, 10.0, 20.0), (0.1, 0.3, 1.0, 3.0)
TAUS_NW, BETAS_NW, LAMS = (5.0, 20.0), (0.1, 0.3, 0.5, 1.0), (0.1, 0.3, 0.5)
configs = [("base", None)]
configs += [("nw_mix", (5.0, 0.3))]
configs += [("nw_resid", (tau, b)) for tau in TAUS_NW for b in BETAS_NW]
configs += [("krig_mix", (tau, rho, l)) for tau in TAUS_K for rho in RHOS for l in LAMS]
configs += [("krig_resid", (tau, rho)) for tau in TAUS_K for rho in RHOS]
nd = {c: np.zeros(len(Q["t"])) for c in configs}
corr_size = {c: np.zeros(len(Q["t"])) for c in configs if c[0] == "krig_resid"}
L, E, bias = lab.L, lab.E, lab.bias
H_keys_all = T["H"][mem.keys]

def nd_of(scores, y):
    return ndcg_hr(ranks_of(scores, y))[0]

chunk = 32
for i in range(0, len(ev), chunk):
    b = ev[i:i + chunk]
    B = len(b)
    y = Q["y"][b]
    kb = kidx[b]; ok = kb >= 0
    kq_cos = sims[b]
    Kv = mem.Kn[np.maximum(kb, 0)]                       # (B,K,D) нормированные ключи
    kk_cos = np.einsum("bkd,bjd->bkj", Kv, Kv)
    Pm = softmax(Q["h"][b] @ E.T + bias, 1)              # (B,L)
    Hk = H_keys_all[np.maximum(kb, 0)]                    # (B,K,D) сырые состояния соседей
    Pk = softmax(Hk @ E.T + bias, -1)                     # (B,K,L) модель на соседях
    Y = np.zeros((B, K, L)); 
    bi, ki = np.nonzero(ok)
    Y[bi, ki, items[b][bi, ki]] = 1.0
    R = Y - Pk
    R[~ok] = 0; Y[~ok] = 0
    nd[("base", None)][b] = nd_of(np.log(Pm + 1e-30), y)
    for tau in set(TAUS_NW) | {5.0}:
        w = softmax(np.where(ok, tau * kq_cos, -np.inf), 1)
        if tau == 5.0:
            q = np.einsum("bk,bkl->bl", w, Y)
            q = np.where(q.sum(1, keepdims=True) > 0, q / np.maximum(q.sum(1, keepdims=True), 1e-12), 1.0 / L)
            nd[("nw_mix", (5.0, 0.3))][b] = nd_of(np.log(0.7 * Pm + 0.3 * q + 1e-30), y)
        if tau in TAUS_NW:
            corr = np.einsum("bk,bkl->bl", w, R)
            for beta in BETAS_NW:
                nd[("nw_resid", (tau, beta))][b] = nd_of(Pm + beta * corr, y)
    eye = np.eye(K)[None]
    for tau in TAUS_K:
        kq = np.where(ok, np.exp(tau * (kq_cos - 1)), 0.0)
        Kmat = np.exp(tau * (kk_cos - 1))
        m2 = ok[:, :, None] & ok[:, None, :]
        Kmat = np.where(m2, Kmat, 0.0) + np.where(~ok, 1.0, 0.0)[:, :, None] * eye
        for rho in RHOS:
            w = np.linalg.solve(Kmat + rho * eye, kq[..., None])[..., 0]
            w = np.where(ok, w, 0.0)
            corr = np.einsum("bk,bkl->bl", w, R)
            nd[("krig_resid", (tau, rho))][b] = nd_of(Pm + corr, y)
            corr_size[("krig_resid", (tau, rho))][b] = w.sum(1)
            qk = np.clip(np.einsum("bk,bkl->bl", w, Y), 0, None)
            s = qk.sum(1, keepdims=True)
            qk = np.where(s > 0, qk / np.maximum(s, 1e-12), 1.0 / L)
            for l in LAMS:
                nd[("krig_mix", (tau, rho, l))][b] = nd_of(np.log((1 - l) * Pm + l * qk + 1e-30), y)
    if (i // chunk) % 40 == 0:
        print(f"  {i}/{len(ev)} {time.time() - t0:.0f}s", flush=True)

base_u = lab.per_user(ti, nd[("base", None)][ti])[1]
nw_u = lab.per_user(ti, nd[("nw_mix", (5.0, 0.3))][ti])[1]
prim = Q["primary"][ti]
out = {}
for fam in ("nw_mix", "nw_resid", "krig_mix", "krig_resid"):
    cands = [c for c in configs if c[0] == fam]
    best = max(cands, key=lambda c: nd[c][vi].mean())
    tu = lab.per_user(ti, nd[best][ti])[1]
    d = tu - base_u; lo, hi, p = paired_bootstrap(d)
    d2 = tu - nw_u; lo2, hi2, p2 = paired_bootstrap(d2)
    dl = nd[best][ti][prim] - nd[("base", None)][ti][prim]; lo3, hi3, _ = paired_bootstrap(dl)
    out[fam] = dict(params=best[1], val=float(nd[best][vi].mean()), ndcg_all=float(tu.mean()), d_all=float(d.mean()),
                    ci_all=(lo, hi), p_all=p, vs_nw=float(d2.mean()), vs_nw_ci=(lo2, hi2), vs_nw_p=p2,
                    ndcg_last=float(nd[best][ti][prim].mean()), d_last=float(dl.mean()), ci_last=(lo3, hi3))
    if fam == "krig_resid":
        ws = corr_size[best][ti]
        out[fam]["sum_w_mean"] = float(ws.mean()); out[fam]["sum_w_q10_q90"] = (float(np.quantile(ws, 0.1)), float(np.quantile(ws, 0.9)))
        out[fam]["grid_val"] = {f"tau={c[1][0]},rho={c[1][1]}": float(nd[c][vi].mean()) for c in cands}
    print(fam, json.dumps(out[fam], default=float, ensure_ascii=False), flush=True)
# где помогает кригинг относительно softmax-смеси: по длине истории
sl = Q["seqlen"][ti]; qs = np.quantile(sl, [1 / 3, 2 / 3])
best_k = out["krig_resid"]["params"]
rows = []
for lo_, hi_, lbl in ((0, qs[0], "короткая"), (qs[0], qs[1], "средняя"), (qs[1], 1e9, "длинная")):
    m = (sl > lo_) & (sl <= hi_)
    a = lab.per_user(ti[m], nd[("krig_resid", tuple(best_k))][ti][m] - nd[("base", None)][ti][m])[1]
    c = lab.per_user(ti[m], nd[("nw_mix", (5.0, 0.3))][ti][m] - nd[("base", None)][ti][m])[1]
    rows.append(dict(bin=lbl, krig=float(a.mean()), krig_ci=paired_bootstrap(a)[:2], nw=float(c.mean())))
out["by_len"] = rows
print(json.dumps(rows, default=float, ensure_ascii=False))
json.dump(out, open(f"{WORK}/results_kriging.json", "w"), indent=1, default=float, ensure_ascii=False)
print("done %.0fs" % (time.time() - t0))
