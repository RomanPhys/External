"""Ритейл: retrieval с памятью того же типа, что запрос, и разложение G (население) против L (похожие ситуации).

Запросы стоят на границах чеков (таргет = первый товар следующего заказа), а 95% переходов в памяти
это достройка корзины внутри чека. Память «граничных» переходов: ключ = состояние после последнего
товара чека, значение = первый товар следующего чека, время = момент следующего чека.
"""
import json, pickle, time
import numpy as np
import pandas as pd
from config import WORK, load_encoder
from encoder import ranks_of, ndcg_hr
from agg_eval import Lab, softmax, knn_dense, knn_aux, paired_bootstrap
from retrieval import TransitionMemory
from context import BETAS

t0 = time.time()
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
Q, S, T = lab.Q, lab.S, C["T"]
vi, ti = lab.idx["val"], lab.idx["test"]
ev = np.concatenate([vi, ti])
mem = TransitionMemory(T)
bnd = T["t"][mem.keys + 1] > T["t"][mem.keys]
print(f"transitions {len(mem.keys)}, boundary {bnd.sum()} ({bnd.mean():.1%})", flush=True)


def subset(m, mask):
    m2 = TransitionMemory.__new__(TransitionMemory)
    m2.keys, m2.Kn, m2.val, m2.t_done, m2.user = m.keys[mask], m.Kn[mask], m.val[mask], m.t_done[mask], m.user[mask]
    o = np.argsort(m2.t_done, kind="stable"); m2.by_time, m2.t_sorted = o, m2.t_done[o]
    m2.user_keys = {u: np.flatnonzero(m2.user == u) for u in np.unique(m2.user)}
    m2.T = m.T
    return m2


bmem = subset(mem, bnd)
base = lab.report("base")
OUT = dict(n_transitions=int(len(mem.keys)), boundary_share=float(bnd.mean()), rows=[])
PMv = softmax(Q["h"][vi] @ lab.E.T + lab.bias, 1)


def nd_mix(Pm, Pk, y, lam):
    p = (1 - lam) * Pm + lam * Pk
    t = p[np.arange(len(y)), y]
    r = 1 + (p > t[:, None]).sum(1)
    return np.where(r <= 10, 1.0 / np.log2(r + 1), 0.0)


def tune(items, sims, fixed_tau=None):
    best = (-1, None)
    for K in (20, 50, 100):
        for tau in ((fixed_tau,) if fixed_tau else (5.0, 20.0, 50.0)):
            Pk = knn_dense(items, sims, vi, K, tau, lab.L)
            for lam in (0.05, 0.1, 0.2, 0.3, 0.5):
                v = nd_mix(PMv, Pk, Q["y"][vi], lam).mean()
                if v > best[0]:
                    best = (v, (K, tau, lam))
    return best[1]


def row(name, items, sims, fixed_tau=None):
    K, tau, lam = tune(items, sims, fixed_tau)
    r = lab.report(name, aux=knn_aux(lab, items, sims, K, tau), lam=lam, base=base)
    cov = (items[ti, :K] == Q["y"][ti][:, None]).any(1).mean()
    d = dict(name=name, K=K, tau=tau, lam=lam, ndcg_all=r["ndcg_all"], d_all=r["d_user"], ci_all=r["ci_user"],
             p_all=r["p_user"], ndcg_last=r["ndcg_last"], d_last=r["d_last"], coverage=float(cov))
    OUT["rows"].append(d)
    print(f"{name:<55} K={K} tau={tau} lam={lam} all {r['ndcg_all']:.4f} d {r['d_user']:+.4f} "
          f"[{r['ci_user'][0]:+.4f},{r['ci_user'][1]:+.4f}] p={r['p_user']:.3f} cov {cov:.3f}", flush=True)
    return d, (K, tau, lam)


VAR = {}
for name, m, kw in [("все переходы, причинно", mem, dict(mode="causal")),
                    ("граничные переходы, причинно", bmem, dict(mode="causal")),
                    ("граничные, с будущим (утечка)", bmem, dict(mode="noncausal")),
                    ("граничные, только последние 30 дней", bmem, dict(mode="window", days=30)),
                    ("граничные, случайные (контроль)", bmem, dict(mode="random")),
                    ("граничные, 50 самых похожих клиентов", bmem, dict(mode="users", users_k=50, S=S))]:
    it, sm, ow = m.query(Q, ev, K=100, **kw)
    VAR[name] = (it, sm)
    row(name, it, sm, fixed_tau=1.0 if kw["mode"] == "random" else None)
print("variants %.0fs" % (time.time() - t0), flush=True)

# ---------- G + L: глобальный вектор в эмбеддинге и граничный retrieval в вероятностях ----------
itb, smb = VAR["граничные переходы, причинно"]
Kb, taub, lamb = tune(itb, smb)
G_fn = lambda idx: S["g_beta"][idx, BETAS.index(2.0)]
best = (-1, None)
Gv = G_fn(vi)
Pk_v = knn_dense(itb, smb, vi, Kb, taub, lab.L)
for a in (0.0, 0.2, 0.3, 0.4, 0.5, 0.6):
    U = lab.mix(vi, Gv, a)
    Pm = softmax(U @ lab.E.T + lab.bias, 1)
    for lam in (0.0, 0.05, 0.1, 0.2, 0.3, 0.5):
        v = nd_mix(Pm, Pk_v, Q["y"][vi], lam).mean()
        if v > best[0]:
            best = (v, (a, lam))
aGL, lGL = best[1]
# лучшие одиночные на val: G-only alpha и L-only lambda
bestG = max(((a, lab.eval(vi, lab.mix(vi, Gv, a))[0].mean()) for a in (0.2, 0.3, 0.4, 0.5, 0.6)), key=lambda x: x[1])[0]
aux_b = knn_aux(lab, itb, smb, Kb, taub)


def nd_test(alpha, lam):
    U = lab.mix(ti, G_fn(ti), alpha) if alpha > 0 else None
    nd = lab.eval(ti, U, aux=aux_b if lam > 0 else None, lam=lam)[0]
    return nd


v0 = nd_test(0, 0); vG = nd_test(bestG, 0); vL = nd_test(0, lamb); vGL = nd_test(aGL, lGL)
U = lambda nd: lab.per_user(ti, nd)[1]
sh = dict(phi_G=0.5 * ((U(vG) - U(v0)).mean() + (U(vGL) - U(vL)).mean()),
          phi_L=0.5 * ((U(vL) - U(v0)).mean() + (U(vGL) - U(vG)).mean()),
          interaction=(U(vGL) - U(vG) - U(vL) + U(v0)).mean())
dGL = U(vGL) - U(v0)
OUT["G_plus_L"] = dict(alpha_G_only=bestG, lam_L_only=lamb, alpha=aGL, lam=lGL, ndcg_all=float(U(vGL).mean()),
                       d_all=float(dGL.mean()), ci_all=paired_bootstrap(dGL)[:2],
                       d_G=float((U(vG) - U(v0)).mean()), ci_G=paired_bootstrap(U(vG) - U(v0))[:2],
                       d_L=float((U(vL) - U(v0)).mean()), ci_L=paired_bootstrap(U(vL) - U(v0))[:2],
                       shapley=sh)
print("G+L", json.dumps(OUT["G_plus_L"], default=float, ensure_ascii=False), flush=True)

# ---------- сезон: запросы в сентябре-декабре против остальных месяцев ----------
month = pd.to_datetime(Q["t"][ti], unit="s").month.to_numpy()
season = month >= 9
OUT["season"] = []
for lbl, m in (("сентябрь-декабрь", season), ("январь-август", ~season)):
    res = dict(slice=lbl, n_queries=int(m.sum()), base=float(v0[m].mean()))
    for key, nd in (("G", vG), ("L", vL), ("G+L", vGL)):
        u, d = lab.per_user(ti[m], nd[m] - v0[m])
        lo, hi, _ = paired_bootstrap(d)
        res[key] = float(d.mean()); res[key + "_ci"] = (lo, hi)
    OUT["season"].append(res)
    print("season", res, flush=True)

json.dump(OUT, open(f"{WORK}/results_retail_retrieval.json", "w"), indent=1, default=float, ensure_ascii=False)
print("done %.0fs" % (time.time() - t0))
