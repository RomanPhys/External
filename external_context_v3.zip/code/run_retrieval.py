"""Разложение эффекта через память переходов + адаптивный шлюз retrieval (новый метод)."""
import json, pickle, time
import numpy as np
from encoder import ranks_of, ndcg_hr
from config import WORK, load_encoder
from agg_eval import Lab, softmax, knn_aux, knn_dense, paired_bootstrap, Adam
from retrieval import TransitionMemory, dedupe_owner

t0 = time.time()
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
model = load_encoder()
lab = Lab(model, C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
Q, S = lab.Q, lab.S
mem = TransitionMemory(C["T"])
vi, ti, tri = lab.idx["val"], lab.idx["test"], lab.idx["train"]
ev = np.concatenate([vi, ti])
LOG = open(f"{WORK}/retrieval.log", "w")
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.write(s + "\n"); LOG.flush()

base = lab.report("Without context")
OUT = dict(rows=[])

PM = {}
def pm(idx_name):
    if idx_name not in PM:
        idx = lab.idx[idx_name]
        PM[idx_name] = softmax(Q["h"][idx] @ lab.E.T + lab.bias, 1)
    return PM[idx_name]

def nd_mix(Pm, Pk, y, lam):
    p = (1 - lam) * Pm + lam * Pk
    t = p[np.arange(len(y)), y]
    r = 1 + (p > t[:, None]).sum(1)
    return np.where(r <= 10, 1.0 / np.log2(r + 1), 0.0)

def run_variant(name, items, sims, fixed_tau=None, Ks=(20, 50, 100)):
    taus = (fixed_tau,) if fixed_tau is not None else (5.0, 20.0, 50.0)
    best = (-1, None)
    Pm_v, yv = pm("val"), Q["y"][vi]
    for K in Ks:
        for tau in taus:
            Pk = knn_dense(items, sims, vi, K, tau, lab.L)
            for lam in (0.05, 0.1, 0.2, 0.3, 0.5):
                v = nd_mix(Pm_v, Pk, yv, lam).mean()
                if v > best[0]:
                    best = (v, (K, tau, lam))
    K, tau, lam = best[1]
    r = lab.report(name, aux=knn_aux(lab, items, sims, K, tau), lam=lam, base=base)
    # покрытие: как часто таргет вообще есть среди K извлечённых следующих айтемов
    cov = (items[ti, :K] == Q["y"][ti][:, None]).any(1).mean()
    row = dict(name=name, K=K, tau=tau, lam=lam, ndcg_last=r["ndcg_last"], ndcg_all=r["ndcg_all"],
               hr_all=r["hr_all"], d_all=r["d_user"], ci_all=r["ci_user"], p_all=r["p_user"],
               d_last=r["d_last"], ci_last=r["ci_last"], target_coverage=float(cov))
    OUT["rows"].append(row)
    log(f"{name:<52} K={K} tau={tau} lam={lam}  all {r['ndcg_all']:.4f} d {r['d_user']:+.4f} "
        f"[{r['ci_user'][0]:+.4f},{r['ci_user'][1]:+.4f}] p={r['p_user']:.3f} | last {r['ndcg_last']:.4f} "
        f"d {r['d_last']:+.4f} | coverage {cov:.3f}")
    return row

variants = {}
for name, kw in [("causal: вся причинная память", dict(mode="causal")),
                 ("noncausal: с будущим (утечка, верхняя граница)", dict(mode="noncausal")),
                 ("window 30 дн.: только свежие переходы", dict(mode="window", days=30)),
                 ("window 365 дн.", dict(mode="window", days=365)),
                 ("stale 30 дн.: только переходы старше месяца", dict(mode="stale", days=30)),
                 ("stale 365 дн.", dict(mode="stale", days=365)),
                 ("random: K случайных причинных (контроль)", dict(mode="random")),
                 ("users 10: переходы 10 самых похожих клиентов", dict(mode="users", users_k=10, S=S)),
                 ("users 50: переходы 50 самых похожих клиентов", dict(mode="users", users_k=50, S=S))]:
    it, sm, ow = mem.query(Q, ev, K=100, **kw)
    variants[name] = (it, sm, ow)
    log(f"  built {name} {time.time() - t0:.0f}s")
    run_variant(name, it, sm, fixed_tau=1.0 if kw["mode"] == "random" else None)
it, sm, ow = variants["causal: вся причинная память"]
d_it, d_sm = dedupe_owner(it, sm, ow)
run_variant("causal, по одному переходу от клиента", d_it, d_sm)

# ---------- вариант в форме вектора контекста (совместим с пайплайном статьи) ----------
best = (-1, None)
for K in (20, 50, 100):
    for tau in (5.0, 20.0, 50.0):
        def G(idx, K=K, tau=tau):
            itq, smq = it[idx, :K], sm[idx, :K]
            ok = itq >= 0
            w = softmax(np.where(ok, tau * smq, -np.inf), 1)
            return np.einsum("bk,bkd->bd", w, lab.E[np.maximum(itq, 0)])
        Gv = G(vi)
        for a in (0.05, 0.1, 0.2, 0.3, 0.5):
            v = lab.eval(vi, lab.mix(vi, Gv, a))[0].mean()
            if v > best[0]:
                best = (v, (K, tau, a))
K, tau, a = best[1]
def Gbest(idx):
    itq, smq = it[idx, :K], sm[idx, :K]
    ok = itq >= 0
    w = softmax(np.where(ok, tau * smq, -np.inf), 1)
    return np.einsum("bk,bkd->bd", w, lab.E[np.maximum(itq, 0)])
r = lab.report("vector: g = sum w_i E[next_i], u=(1-a)h+a g", Gbest, alpha=a, base=base)
OUT["vector_form"] = dict(K=K, tau=tau, alpha=a, ndcg_all=r["ndcg_all"], d_all=r["d_user"], ci_all=r["ci_user"],
                          p_all=r["p_user"], ndcg_last=r["ndcg_last"], d_last=r["d_last"])
log("vector form", OUT["vector_form"])

# ---------- НОВЫЙ МЕТОД: адаптивный шлюз retrieval (lambda своя для каждого запроса) ----------
causal_row = [r_ for r_ in OUT["rows"] if r_["name"].startswith("causal: вся")][0]
Kc, tauc, lamc = causal_row["K"], causal_row["tau"], causal_row["lam"]
it_tr, sm_tr, _ = mem.query(Q, tri, K=100, mode="causal")
log(f"  train retrieval built {time.time() - t0:.0f}s")
it_all = np.where(np.isin(np.arange(len(Q["t"])), tri)[:, None], it_tr, it)
sm_all = np.where(np.isin(np.arange(len(Q["t"])), tri)[:, None], sm_tr, sm)
aux = knn_aux(lab, it_all, sm_all, Kc, tauc)

def pieces(idx, chunk=1024):
    """p_model(y), p_knn(y) и признаки уверенности для каждого запроса."""
    pm_y, pk_y, F = [], [], []
    for i in range(0, len(idx), chunk):
        b = idx[i:i + chunk]
        pm = softmax(lab.Q["h"][b] @ lab.E.T + lab.bias, 1)
        pk = aux(b)
        y = Q["y"][b]
        pm_y.append(pm[np.arange(len(b)), y]); pk_y.append(pk[np.arange(len(b)), y])
        sims_b = sm_all[b, :Kc]
        w = softmax(np.where(it_all[b, :Kc] >= 0, tauc * sims_b, -np.inf), 1)
        F.append(np.stack([sims_b[:, 0], sims_b[:, :10].mean(1), -(w * np.log(w + 1e-12)).sum(1),
                           pk.max(1), pm.max(1), -(pm * np.log(pm + 1e-12)).sum(1),
                           np.log(Q["seqlen"][b]), np.log1p(np.maximum(Q["gap"][b], 0) / 3600)], 1))
    return np.concatenate(pm_y), np.concatenate(pk_y), np.concatenate(F)

fnames = ["top1 cos", "mean top10 cos", "энтропия весов", "max p_knn", "max p_model", "энтропия p_model",
          "log длины", "log паузы (ч)"]
pm_tr, pk_tr, F_tr = pieces(tri)
mu, sd = F_tr.mean(0), F_tr.std(0) + 1e-6
Fz = (F_tr - mu) / sd
w = np.zeros(F_tr.shape[1]); b0 = np.array([np.log(lamc / (1 - lamc))])
opt = Adam([w, b0], lr=0.02)
for it_ in range(600):
    z = Fz @ w + b0[0]; lam = 1 / (1 + np.exp(-z))
    p = (1 - lam) * pm_tr + lam * pk_tr
    dlam = -(pk_tr - pm_tr) / (p + 1e-12)
    dz = dlam * lam * (1 - lam) / len(z)
    opt.step([Fz.T @ dz, np.array([dz.sum()])])
nll = -np.log((1 - lam) * pm_tr + lam * pk_tr + 1e-12).mean()
nll_fixed = -np.log((1 - lamc) * pm_tr + lamc * pk_tr + 1e-12).mean()
log(f"adaptive gate train NLL {nll:.4f} vs fixed lam {nll_fixed:.4f} vs model only {-np.log(pm_tr + 1e-12).mean():.4f}")

def eval_vec_lam(idx, chunk=1024):
    nd = np.zeros(len(idx)); lam_out = np.zeros(len(idx))
    _, _, F = pieces(idx)
    lam_all = 1 / (1 + np.exp(-(((F - mu) / sd) @ w + b0[0])))
    for i in range(0, len(idx), chunk):
        bb = idx[i:i + chunk]; lm = lam_all[i:i + chunk]
        p = softmax(Q["h"][bb] @ lab.E.T + lab.bias, 1) * (1 - lm)[:, None] + lm[:, None] * aux(bb)
        nd[i:i + chunk] = ndcg_hr(ranks_of(np.log(p + 1e-30), Q["y"][bb]))[0]
    return nd, lam_all

nd_t, lam_t = eval_vec_lam(ti)
prim = Q["primary"][ti]
_, ndu = lab.per_user(ti, nd_t)
dd = ndu - base["_nd_user"]; lo, hi, p = paired_bootstrap(dd)
dl = nd_t[prim] - base["_nd_last"]; lo2, hi2, p2 = paired_bootstrap(dl)
# сравнение с фиксированной lambda (та же память): прирост именно от адаптивности
fixed_nd = lab.eval(ti, aux=aux, lam=lamc)[0]
_, fixed_u = lab.per_user(ti, fixed_nd)
lo3, hi3, p3 = paired_bootstrap(ndu - fixed_u)
OUT["adaptive"] = dict(ndcg_all=float(ndu.mean()), d_all=float(dd.mean()), ci_all=(lo, hi), p_all=p,
                       ndcg_last=float(nd_t[prim].mean()), d_last=float(dl.mean()), ci_last=(lo2, hi2),
                       vs_fixed=float((ndu - fixed_u).mean()), vs_fixed_ci=(lo3, hi3), vs_fixed_p=p3,
                       weights=dict(zip(fnames, w.tolist())), lam_mean=float(lam_t.mean()),
                       lam_q10=float(np.quantile(lam_t, 0.1)), lam_q90=float(np.quantile(lam_t, 0.9)),
                       K=Kc, tau=tauc, lam_fixed=lamc, train_nll=float(nll), train_nll_fixed=float(nll_fixed))
log("adaptive", OUT["adaptive"])

# где помогает адаптивный retrieval: по длине истории
sl = Q["seqlen"][ti]; qs = np.quantile(sl, [1 / 3, 2 / 3])
nd0 = lab.eval(ti)[0]
OUT["adaptive_by_len"] = []
for lo_, hi_, lbl in ((0, qs[0], "короткая"), (qs[0], qs[1], "средняя"), (qs[1], 1e9, "длинная")):
    m = (sl > lo_) & (sl <= hi_)
    u, d = lab.per_user(ti[m], nd_t[m] - nd0[m])
    a_, b_, p_ = paired_bootstrap(d)
    OUT["adaptive_by_len"].append(dict(bin=lbl, len_range=(float(lo_), float(min(hi_, sl.max()))), base=float(nd0[m].mean()),
                                       gain=float(d.mean()), ci=(a_, b_), lam_mean=float(lam_t[m].mean())))
log("adaptive by len", OUT["adaptive_by_len"])

def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    return o
json.dump(clean(OUT), open(f"{WORK}/results_retrieval.json", "w"), indent=1, ensure_ascii=False)
log("done %.0fs" % (time.time() - t0))
