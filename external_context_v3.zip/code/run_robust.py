"""Проверка устойчивости ключевых выводов на другом энкодере (EXT_WORK указывает на его папку)."""
import json, pickle, time
import numpy as np
from config import WORK, load_encoder
from agg_eval import Lab, softmax, train_learnable_attention, knn_aux
from context import BETAS

t0 = time.time()
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
S = lab.S
vi = lab.idx["val"]
rows = []
def keep(r):
    rows.append({k: v for k, v in r.items() if not k.startswith("_")})
    print(f"{r['name']:<46} last {r['ndcg_last']:.4f} all {r['ndcg_all']:.4f}"
          + (f" d_all {r['d_user']:+.4f} [{r['ci_user'][0]:+.4f},{r['ci_user'][1]:+.4f}]" if "d_user" in r else ""), flush=True)
    return r
base = keep(lab.report("Без контекста"))
keep(lab.report("Mean пул авторов, a по val", lambda idx: lab.rows_mean("fixed_rows", idx, zeros_count=True), base=base))
keep(lab.report("Mean пул авторов, a=0.1", lambda idx: lab.rows_mean("fixed_rows", idx, zeros_count=True), alpha=0.1, base=base))
keep(lab.report("L: 10 ближайших, a по val", lambda idx: lab.rows_mean("top_rows", idx, 0, 10), base=base))
A, curve, ep = train_learnable_attention(lab, 0.1, epochs=10, log=lambda s: None)
keep(lab.report("Learnable attention a=0.1", lambda idx: lab.fixed_attention(idx, A), alpha=0.1, base=base))
best = (-1, None)
for K in (20, 50, 100):
    for tau in (5.0, 20.0):
        aux = knn_aux(lab, S["fret_items"], S["fret_sims"], K, tau)
        for lam in (0.1, 0.2, 0.3, 0.5):
            v = lab.eval(vi, aux=aux, lam=lam)[0].mean()
            if v > best[0]:
                best = (v, (K, tau, lam))
K, tau, lam = best[1]
keep(lab.report(f"Retrieval переходов (K={K}, tau={tau}, lam={lam})", aux=knn_aux(lab, S["fret_items"], S["fret_sims"], K, tau),
                lam=lam, base=base))
json.dump(dict(rows=rows, runtime=time.time() - t0), open(f"{WORK}/results_robust.json", "w"), indent=1,
          ensure_ascii=False, default=float)
