"""Контроль протокола авторов: в recsys/main.py после предобучения модель учится ещё
n_exttrain_epochs эпох (при freeze=False вместе с энкодером), и в train.py лучший чекпойнт
выбирается по NDCG на тех же пользователях, на которых потом считается метрика.
Здесь мы дообучаем энкодер БЕЗ всякого внешнего контекста и смотрим, сколько «прироста»
даёт одна только комбинация «лишние эпохи + максимум по тесту»."""
import json
from config import WORK
import numpy as np
from data import prepare
from encoder import MSEMA, ranks_of, ndcg_hr

seqs, split, L, info = prepare()
tr = [seqs[u][0] for u in seqs if split[u] == "train"]
va = [seqs[u][0] for u in seqs if split[u] == "val"]
te = [seqs[u][0] for u in seqs if split[u] == "test"]

def last_eval(m, group):
    H = np.stack([m.seq_states(s[:-1])[-1] for s in group])
    y = np.array([s[-1] - 1 for s in group])
    return ndcg_hr(ranks_of(m.scores(H), y))[0]

out = []
for seed in (1, 2):
    m = MSEMA.load(f"{WORK}/encoder_msema.npz")
    base_test = last_eval(m, te).mean()
    rec = []
    def val_fn(mm):
        v = last_eval(mm, va).mean(); t = last_eval(mm, te).mean()
        rec.append((v, t)); return v
    m.fit(tr, val_fn, epochs=10, batch=64, lr=2e-3, patience=100, seed=seed, log=lambda s: None)
    v = np.array([r[0] for r in rec]); t = np.array([r[1] for r in rec])
    out.append(dict(seed=seed, base_test=float(base_test), test_by_epoch=t.tolist(), val_by_epoch=v.tolist(),
                    max_test=float(t.max()), test_at_best_val=float(t[v.argmax()])))
    print(out[-1], flush=True)
json.dump(out, open(f"{WORK}/selection_bias.json", "w"), indent=1)
