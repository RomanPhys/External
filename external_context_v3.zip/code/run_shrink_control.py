"""Контроль «чистое сжатие»: u = (1 - a) h, то есть g = 0. Если он даёт столько же, сколько среднее
по населению, то «контекст в целом» работает как калибровка температуры логитов, а не как информация."""
import json, pickle
import numpy as np
from config import WORK, load_encoder
from agg_eval import Lab
from context import BETAS
C = pickle.load(open(f"{WORK}/cache_context.pkl", "rb"))
lab = Lab(load_encoder(), C["T"], C["Q"], C["S"], C["L"], day_cum=C["day_cum"])
S = lab.S
base = lab.report("base")
rows = []
D = lab.HT.shape[1]
conds = {"сжатие: g = 0": lambda idx: np.zeros((len(idx), D), np.float32),
         "G: среднее по всем активным": lambda idx: S["g_all"][idx],
         "G: softmax beta=2": lambda idx: S["g_beta"][idx, BETAS.index(2.0)],
         "Mean, пул авторов (с нулями)": lambda idx: lab.rows_mean("fixed_rows", idx, zeros_count=True)}
for name, fn in conds.items():
    r = lab.report(name, fn, base=base)
    rows.append(dict(name=name, alpha=r["alpha"], d_all=r["d_user"], ci_all=r["ci_user"], ndcg_all=r["ndcg_all"]))
    print(f"{name:<34} a={r['alpha']:<4} d_all {r['d_user']:+.4f} [{r['ci_user'][0]:+.4f},{r['ci_user'][1]:+.4f}]", flush=True)
# прирост G поверх оптимального сжатия: alpha подобран для сжатия, потом добавляем среднее с тем же весом
a0 = rows[0]["alpha"]
nd_shrink = lab.eval(lab.idx["test"], lab.mix(lab.idx["test"], np.zeros((len(lab.idx["test"]), D), np.float32), a0))[0]
best = (-1, None)
for a in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6):
    for c in (0.0, 0.5, 1.0, 1.5, 2.0):
        vi = lab.idx["val"]
        u = (1 - a) * lab.Q["h"][vi] + a * c * S["g_beta"][vi, BETAS.index(2.0)]
        v = lab.eval(vi, u)[0].mean()
        if v > best[0]:
            best = (v, (a, c))
a, c = best[1]
ti = lab.idx["test"]
nd_both = lab.eval(ti, (1 - a) * lab.Q["h"][ti] + a * c * S["g_beta"][ti, BETAS.index(2.0)])[0]
from agg_eval import paired_bootstrap
d = lab.per_user(ti, nd_both)[1] - lab.per_user(ti, nd_shrink)[1]
lo, hi, p = paired_bootstrap(d)
rows.append(dict(name="G сверх оптимального сжатия", alpha=a, g_scale=c, d_vs_shrink=float(d.mean()), ci=(lo, hi), p=p))
print(f"G сверх оптимального сжатия (a={a}, масштаб g={c}): {d.mean():+.4f} [{lo:+.4f},{hi:+.4f}] p={p:.3f}")
json.dump(rows, open(f"{WORK}/results_shrink_control.json", "w"), indent=1, default=float, ensure_ascii=False)
