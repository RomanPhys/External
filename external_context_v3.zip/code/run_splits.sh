#!/bin/bash
# ML-1M на двух других сплитах пользователей: энкодер, контекст, ключевые методы
cd /home/claude/ext/code
for s in 1 2; do
  W=/home/claude/ext/split$s; mkdir -p $W
  EXT_SPLIT_SEED=$s EXT_WORK=$W python3 run_encoder2.py > $W/encoder_train.log 2>&1
  EXT_SPLIT_SEED=$s EXT_WORK=$W python3 run_context.py > $W/context.log 2>&1
  EXT_SPLIT_SEED=$s EXT_WORK=$W python3 run_robust.py > $W/robust.log 2>&1
  echo "split $s done" >> /home/claude/ext/splits_status.log
done
