"""Сводка всех результатов из папки EXT_WORK в одну таблицу (то, что стоит прислать после прогона)."""
import json, os
from config import WORK


def load(name):
    p = os.path.join(WORK, name)
    return json.load(open(p)) if os.path.exists(p) else None


def fmt_ci(d, ci):
    return f"{d:+.4f} [{ci[0]:+.4f}; {ci[1]:+.4f}]"


print(f"=== папка {WORK}")
s = load("sasrec_summary.json")
if s:
    print("\n--- SASRec авторов, чистый протокол")
    print(f"пользователи {s['users']}, айтемов {s['num_items']}, взаимодействий {s['n_interactions']}")
    p = s["pretrained"]
    print(f"предобученный SASRec: val {p['val']:.4f}, test {p['test']:.4f} (метрика авторов на test {p['test_authors_metric']:.4f})")
    c = s.get("extra_epochs_control")
    if c:
        print(f"лишние эпохи без контекста: test при эпохе по val {c['test_at_best_val']:.4f} (эпоха {c['best_val_epoch']}), "
              f"максимум по test {c['max_test']:.4f} (эпоха {c['max_test_epoch']}), "
              f"разница с предобученным {fmt_ci(c['d_vs_pretrained_at_best_val'], c['ci'])}")
    for name, r in (s.get("authors_agg") or {}).items():
        line = f"агрегация авторов {name}: "
        if "test_at_best_val" in r:
            line += f"test при эпохе по val {r['test_at_best_val']:.4f}, максимум по test {r['max_test']:.4f}, "
            line += f"к предобученному {fmt_ci(r['d_vs_pretrained'], r['ci_vs_pretrained'])}"
            if "d_vs_extra_epochs_control" in r:
                line += f", к контролю лишних эпох {fmt_ci(r['d_vs_extra_epochs_control'], r['ci_vs_control'])}"
        else:
            line += f"test {r['test']:.4f}, к предобученному {fmt_ci(r['d_vs_pretrained'], r['ci'])}"
        w = r.get("future_context_share_in_authors_code")
        if w:
            line += f"; контекст из будущего в коде авторов: {w['train_positions']:.2%} обучающих позиций, {w['test_queries']:.2%} тестовых запросов"
        print(line)

R = load("results.json")
if R:
    print("\n--- numpy-конвейер на выгрузке: Δ NDCG@10 к базе, 5 позиций на пользователя, 95% CI")
    base = [r for r in R["A_replication"] if r["name"] == "Without context"][0]
    print(f"база: последний айтем {base['ndcg_last']:.4f}, 5 позиций {base['ndcg_all']:.4f}; SE {R['meta']['se_last']:.4f} / {R['meta']['se_all']:.4f}")
    keep = ["Mean (пул авторов, a=0.1)", "Mean (пул авторов, a=tuned)", "Attention (пул авторов, tuned)",
            "Learnable attention (a=0.1)", "G: среднее по всем активным", "L: 10 ближайших (mean)",
            "Контроль: 10 ближайших чужого запроса", "NEW Шлюз local/global (обучаемые a, l, beta)",
            "Популярность за окно (дней, lam)"]
    for g in ("A_replication", "B_decomposition", "B_temperature", "C_new"):
        for r in R[g]:
            if "d_user" in r and (any(r["name"].startswith(k) for k in keep) or g == "B_temperature" or "Retrieval" in r["name"]):
                extra = f" α={r['alpha']}" if "alpha" in r else ""
                print(f"  {r['name'][:60]:<60} {fmt_ci(r['d_user'], r['ci_user'])}{extra}")
    print("  Шепли (вектор, 5 позиций):", {k: round(v, 4) for k, v in R["shapley"]["ndcg_all"].items()})

RR = load("results_retrieval.json")
if RR:
    print("\n--- разложение через память переходов")
    for r in RR["rows"]:
        print(f"  {r['name'][:60]:<60} {fmt_ci(r['d_all'], r['ci_all'])} покрытие {r['target_coverage']:.3f}")
    v = RR.get("vector_form")
    if v:
        print(f"  {'векторная форма g = sum w E[next]':<60} {fmt_ci(v['d_all'], v['ci_all'])} α={v['alpha']}")

SC = load("results_shrink_control.json")
if SC:
    print("\n--- контроль g = 0 (чистое сжатие)")
    for r in SC:
        if "d_all" in r:
            print(f"  {r['name']:<40} {fmt_ci(r['d_all'], r['ci_all'])} α={r['alpha']}")
        else:
            print(f"  {r['name']:<40} {fmt_ci(r['d_vs_shrink'], r['ci'])}")

D = load("diagnostics.json")
if D:
    print("\n--- производная CE по доле контекста на val (минус = помогает)")
    print("  стационарность по h:", round(D["val"]["stationarity"]["stationarity_h"], 3))
    for k, v in D["val"]["derivatives"].items():
        val = v.get("dCE_dalpha", v.get("dCE_dlambda"))
        print(f"  {k:<50} {val:+.3f} ± {v['se']:.3f}")
