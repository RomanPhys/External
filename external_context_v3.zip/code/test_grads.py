"""Проверка ручных градиентов MSEMA конечными разностями (float64)."""
import numpy as np
from encoder import MSEMA

rng = np.random.default_rng(1)
L = 30
m = MSEMA(L, gammas=(0.0, 0.7, 0.95), dims=(3, 4, 5), seed=3)
m.dt = np.float64
m.Q = [q.astype(np.float64) for q in m.Q]; m.E = m.E.astype(np.float64); m.b = rng.standard_normal(L)
seqs = [rng.integers(1, L + 1, size=n) for n in (7, 12, 5, 9)]

def loss():
    tot, cnt, _ = m.loss_grads(seqs, last_k=6)
    return tot / cnt

_, _, grads = m.loss_grads(seqs, last_k=6)
params = m.Q + [m.E, m.b]
worst = 0
for pi, (p, g) in enumerate(zip(params, grads)):
    for _ in range(8):
        idx = tuple(rng.integers(0, s) for s in p.shape)
        if pi < 3 and idx[0] == 0:
            continue
        old = p[idx]; e = 1e-6
        p[idx] = old + e; lp = loss(); p[idx] = old - e; lm = loss(); p[idx] = old
        num = (lp - lm) / (2 * e)
        rel = abs(num - g[idx]) / max(1e-4, abs(num) + abs(g[idx]))
        worst = max(worst, rel)
print("max relative error:", worst)
assert worst < 1e-5
print("OK")
