"""Проверка пути EXT_STATES: выгружаем MS-EMA в формате export_sasrec_states.py."""
import os
import numpy as np
from config import WORK
OUT = os.path.join(WORK, 'pre'); os.makedirs(OUT, exist_ok=True)
from data import prepare
from encoder import MSEMA
seqs, split, L, info = prepare()
m = MSEMA.load(f"{WORK}/encoder_msema.npz")
users = sorted(seqs)
code = {"train": 0, "val": 1, "test": 2}
states, offs = [], [0]
for u in users:
    states.append(m.seq_states(seqs[u][0])); offs.append(offs[-1] + len(seqs[u][0]))
np.savez_compressed(os.path.join(OUT, "states.npz"), E=m.E, b=m.b, users=np.array(users), offsets=np.array(offs),
                    items=np.concatenate([seqs[u][0] for u in users]), ts=np.concatenate([seqs[u][1] for u in users]),
                    states=np.concatenate(states).astype(np.float32), split=np.array([code[split[u]] for u in users], np.int8))
print("exported", offs[-1], "rows")
