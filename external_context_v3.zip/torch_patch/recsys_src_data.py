"""Восстановленный модуль recsys/src/data для репозитория petrsokerin/External-Context-Aggregation.

Почему его нет: корневой .gitignore содержит правило `data/`, оно исключило из git
не только папку с датасетами, но и python-пакет recsys/src/data/. Без него
recsys/main.py падает на `from src.data import ...`.

Положить как recsys/src/data/__init__.py. Интерфейс восстановлен по тому, как его
используют recsys/main.py, src/aggregation/agg.py и src/model/train.py:
  * df с колонками user_id, item_id (1..num_items, 0 это паддинг), rating, timestamp;
  * левый паддинг, маска True на настоящих токенах (так делает get_external_vectors);
  * Train: ((seq, times, pad_mask), (targets, label_mask)), всё длины max_len;
  * Val:   ((seq, times, pad_mask), (target, label_mask)), target скаляр (последний айтем).
Сплит user-based, как на рисунке 8 статьи. Точной доли тестовых пользователей у авторов
мы не знаем, по умолчанию 20%, задаётся переменной окружения EXT_TEST_FRAC.
ВНИМАНИЕ: код не запускался в той песочнице, где писался (там не было torch).
"""
import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

TEST_FRAC = float(os.environ.get("EXT_TEST_FRAC", 0.2))
SPLIT_SEED = int(os.environ.get("EXT_SPLIT_SEED", 0))


def download_dataset(*args, **kwargs):
    raise NotImplementedError("Скачайте датасет вручную в data/<name> (см. README авторов).")


def load_data(data_path, dataset_name):
    """Поддерживает ratings.dat MovieLens (UserID::MovieID::Rating::Timestamp), csv и parquet."""
    cands = [os.path.join(data_path, f) for f in ("ratings.dat", f"{dataset_name}.parquet",
                                                  f"{dataset_name}.csv", "ratings.csv")]
    for p in cands:
        if not os.path.exists(p):
            continue
        if p.endswith(".dat"):
            df = pd.read_csv(p, sep="::", engine="python", names=["user_id", "item_id", "rating", "timestamp"])
        elif p.endswith(".parquet"):
            df = pd.read_parquet(p)
        else:
            df = pd.read_csv(p)
        ren = {"userId": "user_id", "movieId": "item_id", "user": "user_id", "item": "item_id", "ts": "timestamp"}
        return df.rename(columns={k: v for k, v in ren.items() if k in df.columns})
    raise FileNotFoundError(f"не нашёл данных в {data_path}: ожидаю один из {cands}")


def _k_core(df, k_user, k_item):
    while True:
        n = len(df)
        ic = df["item_id"].value_counts()
        df = df[df["item_id"].isin(ic[ic >= k_item].index)]
        uc = df["user_id"].value_counts()
        df = df[df["user_id"].isin(uc[uc >= k_user].index)]
        if len(df) == n:
            return df


def prepare_data(df, cfg_dataset):
    if "rating" in df.columns and cfg_dataset.get("mark_thr") is not None:
        df = df[df["rating"] > cfg_dataset["mark_thr"]]
    df = _k_core(df, cfg_dataset.get("filter_users", 5), cfg_dataset.get("filter_items", 5))
    items = np.sort(df["item_id"].unique())
    df = df.assign(item_id=df["item_id"].map({it: i + 1 for i, it in enumerate(items)}))
    df = df.sort_values(["user_id", "timestamp"], kind="stable").reset_index(drop=True)
    return df, len(items)


def get_sequences(df, test_frac=TEST_FRAC, seed=SPLIT_SEED):
    users = np.sort(df["user_id"].unique())
    rng = np.random.default_rng(seed)
    perm = rng.permutation(users)
    n_test = int(round(test_frac * len(users)))
    test_users, train_users = np.sort(perm[:n_test]), np.sort(perm[n_test:])
    g = {u: (x["item_id"].to_numpy(), x["timestamp"].to_numpy()) for u, x in df.groupby("user_id", sort=True)}
    tr_s = [g[u][0] for u in train_users]; tr_t = [g[u][1] for u in train_users]
    te_s = [g[u][0] for u in test_users]; te_t = [g[u][1] for u in test_users]
    return (tr_s, te_s), (tr_t, te_t), (train_users, test_users)


def _left_pad(x, n, fill=0):
    x = list(x)[-n:]
    return [fill] * (n - len(x)) + x


class TrainSASRecDataset(Dataset):
    """Окно из последних max_len+1 событий: вход x[:-1], таргеты x[1:]."""

    def __init__(self, sequences, times, max_len, future_time=False):
        self.s, self.t, self.max_len, self.future = sequences, times, max_len, future_time

    def __len__(self):
        return len(self.s)

    def __getitem__(self, i):
        s, t = self.s[i][-(self.max_len + 1):], self.t[i][-(self.max_len + 1):]
        inp, tgt = s[:-1], s[1:]
        # future_time=True берёт время СЛЕДУЮЩЕГО события: это утечка момента действия
        tim = t[1:] if self.future else t[:-1]
        n = len(inp)
        seq = torch.tensor(_left_pad(inp, self.max_len), dtype=torch.long)
        times = torch.tensor(_left_pad(tim, self.max_len, fill=int(t[0])), dtype=torch.long)
        mask = torch.zeros(self.max_len, dtype=torch.bool); mask[self.max_len - n:] = True
        targets = torch.tensor(_left_pad(tgt, self.max_len), dtype=torch.long)
        return (seq, times, mask), (targets, mask.clone())


class ValSASRecDataset(Dataset):
    """Leave-one-out: вход все события кроме последнего, таргет последний айтем."""

    def __init__(self, sequences, times, max_len, future_time=False):
        self.s, self.t, self.max_len, self.future = sequences, times, max_len, future_time

    def __len__(self):
        return len(self.s)

    def __getitem__(self, i):
        s, t = self.s[i], self.t[i]
        inp = s[:-1][-self.max_len:]
        tim = (t[1:] if self.future else t[:-1])[-self.max_len:]
        n = len(inp)
        seq = torch.tensor(_left_pad(inp, self.max_len), dtype=torch.long)
        times = torch.tensor(_left_pad(tim, self.max_len, fill=int(t[0])), dtype=torch.long)
        mask = torch.zeros(self.max_len, dtype=torch.bool); mask[self.max_len - n:] = True
        return (seq, times, mask), (torch.tensor(int(s[-1]), dtype=torch.long), torch.tensor(True))
