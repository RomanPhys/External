"""SASRec авторов на чистом протоколе: предобучение, выгрузка состояний, контроль лишних эпох,
по желанию агрегации авторов в их собственном коде.

Запуск из папки recsys/ репозитория авторов (после копирования recsys_src_data.py в src/data/__init__.py):

    python sasrec_pipeline.py --config config/main_movielens_1m.yaml --work /content/work
    python sasrec_pipeline.py --config config/main_movielens_1m.yaml --work /content/work \
        --skip_pretrain --extra_epochs 0 --authors_agg mean,learnable_attention --ext_epochs 20

Что отличается от recsys/main.py авторов и почему:
  * тестовые пользователи авторов (20%) делятся на val (1/3) и test (2/3); эпоха и все гиперпараметры
    выбираются по val, итог считается на test (у авторов выбор эпохи идёт по тем же пользователям, что итог);
  * контроль «лишние эпохи без контекста» с тем же оптимизатором, что второй этап авторов;
  * в агрегациях авторов позиции раньше первого события пула получают пустой контекст
    (в agg.py searchsorted(...) - 1 = -1 указывает на последний элемент, то есть на будущее).
Выгрузка совместима с numpy-конвейером: EXT_STATES=<work>/sasrec_states.npz.
"""
import argparse, json, os, time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import yaml

from src.data import load_data, prepare_data, get_sequences, TrainSASRecDataset, ValSASRecDataset
from src.model import SASRec, calculate_ndcg_loss, train_sasrec
from src.aggregation import get_external_vectors, transform_aggregation
from src.utils import fix_seed


# ---------------------------------------------------------------- данные и сплит
def make_split(df, val_share):
    (tr_s, te_s), (tr_t, te_t), (tr_u, te_u) = get_sequences(df)
    rng = np.random.default_rng(0)
    perm = rng.permutation(len(te_u))
    n_val = int(round(val_share * len(te_u)))
    va_i, ts_i = perm[:n_val], perm[n_val:]
    pick = lambda xs, idx: [xs[i] for i in idx]
    return dict(train=(list(tr_s), list(tr_t), np.asarray(tr_u)),
                val=(pick(te_s, va_i), pick(te_t, va_i), np.asarray(te_u)[va_i]),
                test=(pick(te_s, ts_i), pick(te_t, ts_i), np.asarray(te_u)[ts_i]))


def build_model(cfg, num_items, device):
    return SASRec(num_items=num_items, embedding_size=cfg["embedding_size"], num_heads=cfg["num_heads"],
                  num_blocks=cfg["num_blocks"], dropout_rate=cfg["dropout_rate"], final=cfg["final"],
                  max_len=cfg["max_len"]).to(device)


# ---------------------------------------------------------------- обучение и оценка
def run_epoch(model, loader, opt, criterion, num_items, device):
    """Ровно тело цикла из src/model/train.py авторов."""
    model.train()
    tot = 0.0
    for (seqs, times, pmask), (targets, lmask) in loader:
        seqs, times, targets = seqs.to(device), times.to(device), targets.to(device)
        pmask, lmask = pmask.to(device), lmask.to(device)
        targets = targets - 1
        opt.zero_grad()
        out = model(seqs, pmask, times)
        out, targets, lmask = out.reshape(-1, num_items), targets.reshape(-1), lmask.reshape(-1)
        targets = targets.masked_fill(mask=(~lmask), value=-100)
        loss = criterion(out, targets)
        loss.backward()
        opt.step()
        tot += loss.item()
    return tot / len(loader)


@torch.no_grad()
def per_user_ndcg(model, loader, device, k=10):
    """NDCG@10 по всему каталогу для каждого пользователя, ранг = 1 + число айтемов со строго большим скором.
    Та же формула, что в numpy-конвейере, поэтому числа сопоставимы."""
    model.eval()
    res = []
    for (seqs, times, pmask), (targets, _) in loader:
        seqs, times, pmask = seqs.to(device), times.to(device), pmask.to(device)
        targets = targets.to(device) - 1
        scores = model(seqs, pmask, times, val_flag=True)[:, -1, :]
        t = scores.gather(1, targets[:, None])
        rank = 1 + (scores > t).sum(1)
        nd = torch.where(rank <= k, 1.0 / torch.log2(rank.float() + 1), torch.zeros_like(rank, dtype=torch.float))
        res.append(nd.cpu().numpy())
    return np.concatenate(res)


def paired_bootstrap(d, B=4000, seed=0):
    rng = np.random.default_rng(seed)
    bs = d[rng.integers(0, len(d), (B, len(d)))].mean(1)
    lo, hi = np.quantile(bs, [0.025, 0.975])
    p = min(1.0, max(2 * min((bs <= 0).mean(), (bs >= 0).mean()), 1.0 / B))
    return float(lo), float(hi), float(p)


def train_and_track(model, opt, epochs, loaders, criterion, num_items, device, log_name):
    """Учим epochs эпох, после каждой считаем val и test по пользователям."""
    curve, test_arrays = [], []
    for ep in range(epochs):
        t0 = time.time()
        tr_loss = run_epoch(model, loaders["train"], opt, criterion, num_items, device)
        v = per_user_ndcg(model, loaders["val"], device)
        te = per_user_ndcg(model, loaders["test"], device)
        curve.append(dict(epoch=ep + 1, train_loss=tr_loss, val=float(v.mean()), test=float(te.mean())))
        test_arrays.append(te)
        print(f"  [{log_name}] epoch {ep + 1}: loss {tr_loss:.4f} val {v.mean():.4f} test {te.mean():.4f} "
              f"({time.time() - t0:.0f}s)", flush=True)
    best = int(np.argmax([c["val"] for c in curve]))
    return curve, test_arrays, best


# ---------------------------------------------------------------- выгрузка состояний
@torch.no_grad()
def encode(model, items, max_len, device, exact_last=6):
    """Состояние после каждого события. Длинные истории окнами со сдвигом max_len//2 (контекст не меньше
    max_len/2), а последние exact_last позиций пересчитаны точным окном из max_len событий, как в ValSASRecDataset."""
    n = len(items)
    D = model.embedding_size
    out = np.zeros((n, D), np.float32)

    def run(window):
        m = len(window)
        seq = torch.zeros(1, max_len, dtype=torch.long, device=device)
        mask = torch.zeros(1, max_len, dtype=torch.bool, device=device)
        seq[0, max_len - m:] = torch.as_tensor(np.asarray(window), device=device)
        mask[0, max_len - m:] = True
        return model.get_internal_embeddings(seq, mask)[0, max_len - m:].float().cpu().numpy()

    if n <= max_len:
        out[:] = run(items)
        return out
    out[:max_len] = run(items[:max_len])
    half = max_len // 2
    pos = max_len
    while pos < n:
        end = min(pos + half, n)
        st = end - max_len
        out[pos:end] = run(items[st:end])[pos - st:]
        pos = end
    for j in range(max(max_len, n - exact_last), n):
        out[j] = run(items[j - max_len + 1:j + 1])[-1]
    return out


def export_states(model, split, num_items, cfg, device, path):
    model.eval()
    users, seqs, times, codes = [], [], [], []
    for code, name in enumerate(("train", "val", "test")):
        s, t, u = split[name]
        users += list(u); seqs += list(s); times += list(t); codes += [code] * len(u)
    states, offs = [], [0]
    t0 = time.time()
    for k, s in enumerate(seqs):
        states.append(encode(model, np.asarray(s), cfg["max_len"], device))
        offs.append(offs[-1] + len(s))
        if k % 1000 == 0:
            print(f"  export {k}/{len(seqs)} users ({time.time() - t0:.0f}s)", flush=True)
    if cfg["final"] == "items":
        E = model.item_emb.weight[1:].detach().float().cpu().numpy()
        b = np.zeros(num_items, np.float32)
    else:
        E = model.head.weight.detach().float().cpu().numpy()
        b = model.head.bias.detach().float().cpu().numpy()
    np.savez_compressed(path, E=E, b=b, users=np.array(users), offsets=np.array(offs),
                        items=np.concatenate(seqs).astype(np.int64), ts=np.concatenate(times).astype(np.int64),
                        states=np.concatenate(states).astype(np.float32), split=np.array(codes, np.int8))
    print(f"saved {path}", flush=True)


# ---------------------------------------------------------------- агрегации авторов
def patch_causal_lookup(model):
    """Позиции раньше первого события пула получают нулевой контекст вместо контекста из будущего."""
    # у авторов массив float64 и (число моментов x 100 x 64): переводим в float32 один раз, иначе батч весит 300+ МБ
    model.ext_embeddings = np.ascontiguousarray(model.ext_embeddings, dtype=np.float32)
    model.time_to_embeddings = np.ascontiguousarray(model.time_to_embeddings, dtype=np.float32)

    def get_external_embeddings(timestamps):
        bs, seq_len = timestamps.shape
        ts = timestamps.reshape(-1).cpu().detach().numpy()
        ids = np.searchsorted(model.time_list, ts, side="right") - 1
        bad = ids < 0
        ids = np.maximum(ids, 0)
        ctx = model.ext_embeddings[ids]          # индексирование массивом уже создаёт копию
        ctx[bad] = 0.0
        tms = model.time_to_embeddings[ids]
        ext_context = torch.from_numpy(ctx).reshape(bs, seq_len, model.n_ext_users, model.embedding_size)
        ext_times = torch.from_numpy(tms).reshape(bs, seq_len, model.n_ext_users)
        return ext_context, ext_times
    model.get_external_embeddings = get_external_embeddings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--work", required=True)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=None, help="эпох предобучения, по умолчанию n_pretrain_epochs")
    ap.add_argument("--val_share", type=float, default=1 / 3)
    ap.add_argument("--eval_batch", type=int, default=32)
    ap.add_argument("--skip_pretrain", action="store_true")
    ap.add_argument("--extra_epochs", type=int, default=20, help="контроль: столько же эпох без контекста")
    ap.add_argument("--authors_agg", default="", help="например mean,learnable_attention")
    ap.add_argument("--ext_epochs", type=int, default=20)
    ap.add_argument("--alpha", type=float, default=0.1)
    ap.add_argument("--freeze", type=int, default=0)
    ap.add_argument("--no_fix_wrap", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.work, exist_ok=True)
    cfg = yaml.safe_load(open(args.config))
    ds_cfg = yaml.safe_load(open(f"config/dataset/{cfg['defaults'][0]['dataset']}.yaml"))
    fix_seed(args.seed)
    device = torch.device(args.device)
    df = load_data(ds_cfg["data_path"], ds_cfg["dataset_name"])
    df, num_items = prepare_data(df, ds_cfg)
    split = make_split(df, args.val_share)
    sizes = {k: len(v[2]) for k, v in split.items()}
    print(f"interactions {len(df)}, items {num_items}, users {sizes}", flush=True)
    ml = cfg["max_len"]
    loaders = dict(train=DataLoader(TrainSASRecDataset(split["train"][0], split["train"][1], ml), batch_size=cfg["batch_size"], shuffle=True),
                   val=DataLoader(ValSASRecDataset(split["val"][0], split["val"][1], ml), batch_size=args.eval_batch, shuffle=False),
                   test=DataLoader(ValSASRecDataset(split["test"][0], split["test"][1], ml), batch_size=args.eval_batch, shuffle=False))
    criterion = nn.CrossEntropyLoss()
    ckpt_dir = os.path.join(args.work, "checkpoints")
    os.makedirs(ckpt_dir, exist_ok=True)
    ckpt = os.path.join(ckpt_dir, f"sasrec_pretrain_seed{args.seed}.pth")
    summary_path = os.path.join(args.work, "sasrec_summary.json")
    summary = json.load(open(summary_path)) if os.path.exists(summary_path) else {}
    summary.update(dict(num_items=num_items, n_interactions=len(df), users=sizes, config=args.config))

    model = build_model(cfg, num_items, device)
    if not args.skip_pretrain:
        epochs = args.epochs or cfg["n_pretrain_epochs"]
        opt = optim.AdamW(model.parameters(), lr=cfg["lr_pretrain"])
        t0 = time.time()
        # выбор лучшей эпохи по val-пользователям (у авторов это были бы тестовые)
        train_sasrec(model, loaders["train"], loaders["val"], opt, criterion, device, num_items,
                     checkpoint_path=ckpt_dir, mode="pretrain", checkpoint_name=f"sasrec_pretrain_seed{args.seed}",
                     metrics_name=f"sasrec|pretrain_seed{args.seed}.csv", save_mode="prod", epochs=epochs,
                     val_every=cfg["validate_every"])
        summary["pretrain_minutes"] = (time.time() - t0) / 60
        summary["pretrain_epochs"] = epochs
    model.load_state_dict(torch.load(ckpt, map_location=device))
    base_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    v0, t0_ = per_user_ndcg(model, loaders["val"], device), per_user_ndcg(model, loaders["test"], device)
    summary["pretrained"] = dict(val=float(v0.mean()), test=float(t0_.mean()),
                                 test_authors_metric=float(calculate_ndcg_loss(model, loaders["test"], criterion, device)[0]))
    print("pretrained:", summary["pretrained"], flush=True)
    np.save(os.path.join(args.work, "test_ndcg_pretrained.npy"), t0_)
    states_path = os.path.join(args.work, "sasrec_states.npz")
    if not os.path.exists(states_path) or not args.skip_pretrain:
        export_states(model, split, num_items, cfg, device, states_path)

    # контроль: лишние эпохи без контекста, оптимизатор второго этапа авторов (Adam, lr_exttrain)
    if args.extra_epochs > 0:
        model.load_state_dict(base_state)
        opt = optim.Adam(model.parameters(), lr=cfg["lr_exttrain"])
        curve, arrs, best = train_and_track(model, opt, args.extra_epochs, loaders, criterion, num_items, device, "no-context")
        tests = np.array([c["test"] for c in curve])
        d = arrs[best] - t0_
        summary["extra_epochs_control"] = dict(curve=curve, best_val_epoch=best + 1, test_at_best_val=float(tests[best]),
                                               max_test=float(tests.max()), max_test_epoch=int(tests.argmax()) + 1,
                                               d_vs_pretrained_at_best_val=float(d.mean()), ci=paired_bootstrap(d)[:2])
        np.save(os.path.join(args.work, "test_ndcg_extra_epochs.npy"), arrs[best])
        print("extra-epochs control:", {k: v for k, v in summary["extra_epochs_control"].items() if k != "curve"}, flush=True)

    # агрегации авторов в их коде, тот же чистый выбор эпохи по val
    aggs = [a for a in args.authors_agg.split(",") if a]
    ctrl = np.load(os.path.join(args.work, "test_ndcg_extra_epochs.npy")) if os.path.exists(
        os.path.join(args.work, "test_ndcg_extra_epochs.npy")) else None
    for agg in aggs:
        fix_seed(args.seed)
        m = build_model(cfg, num_items, device)
        m.load_state_dict(base_state)
        # у авторов история длины, кратной max_len (400, 600, ...), даёт пустой последний кусок: исключаем таких из пула
        safe = np.array([u for u, s in zip(split["train"][2], split["train"][0]) if not (len(s) > ml and len(s) % ml == 0)])
        user_emb, all_ts = get_external_vectors(m, device, df, safe, cfg["n_ext_users"])
        tl, tte, ext = transform_aggregation(all_ts, user_emb, cfg["n_ext_users"], cfg["embedding_size"])
        m.add_external_features(tl, tte, ext, head_method="adding", agg_type=agg, freezing=bool(args.freeze),
                                alpha=args.alpha, external_only=False,
                                additional_config=cfg["aggregations"][agg]["additional_config"])
        m.to(device)
        # сколько настоящих позиций у авторов получили бы контекст из будущего (индекс -1 = последний момент)
        first = tl[0]
        tr_pos = np.concatenate([np.asarray(t)[-(ml + 1):-1] for t in split["train"][1]])
        te_last = np.array([np.asarray(t)[-2] for t in split["test"][1]])
        wrap = dict(train_positions=float((tr_pos < first).mean()), test_queries=float((te_last < first).mean()))
        if not args.no_fix_wrap:
            patch_causal_lookup(m)
        learnable = cfg["aggregations"][agg]["learnable"]
        res = dict(alpha=args.alpha, freeze=args.freeze, ext_epochs=args.ext_epochs)
        if args.freeze and not learnable:
            te = per_user_ndcg(m, loaders["test"], device)
            res.update(test=float(te.mean()), d_vs_pretrained=float((te - t0_).mean()), ci=paired_bootstrap(te - t0_)[:2])
        else:
            opt = optim.Adam([p for p in m.parameters() if p.requires_grad], lr=cfg["lr_exttrain"])
            curve, arrs, best = train_and_track(m, opt, args.ext_epochs, loaders, criterion, num_items, device, agg)
            tests = np.array([c["test"] for c in curve])
            te = arrs[best]
            res.update(curve=curve, best_val_epoch=best + 1, test_at_best_val=float(tests[best]), max_test=float(tests.max()),
                       d_vs_pretrained=float((te - t0_).mean()), ci_vs_pretrained=paired_bootstrap(te - t0_)[:2])
            if ctrl is not None and len(ctrl) == len(te):
                res.update(d_vs_extra_epochs_control=float((te - ctrl).mean()), ci_vs_control=paired_bootstrap(te - ctrl)[:2])
        res["future_context_share_in_authors_code"] = wrap
        res["fixed_wrap"] = not args.no_fix_wrap
        summary.setdefault("authors_agg", {})[f"{agg}|freeze={args.freeze}|alpha={args.alpha}"] = res
        print(agg, {k: v for k, v in res.items() if k != "curve"}, flush=True)
        json.dump(summary, open(summary_path, "w"), indent=1)
    json.dump(summary, open(summary_path, "w"), indent=1)
    print("summary ->", summary_path)


if __name__ == "__main__":
    main()
